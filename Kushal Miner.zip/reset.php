<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer classes
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';
require 'includes/settings.php';

// Include the database configuration file
include 'config/dbconfig.php';

// Start the session
session_start();

// Initialize the response array
$response = array();

// Check if username is provided through POST
if (isset($_POST['username'])) {
    $username = $_POST['username'];

    // Check if the username exists in the database
    $checkUserQuery = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($checkUserQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User found, check if email is set
        $row = $result->fetch_assoc();
        $email = $row['email'];

        if (empty($email)) {
            $response['status'] = 'error';
            $response['error'] = 'Email not set for the user';
        } else {
            // Generate a random 10-character auth_token
            $auth_token = bin2hex(random_bytes(10));

            // Get the current date and time in GMT
            $created_at = gmdate('Y-m-d H:i:s');

            // Calculate the expiration time (1 hour from the current time)
            $expiring_at = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime($created_at)));

            // Insert data into the password_reset table
            $insertResetQuery = "INSERT INTO password_reset (username, email, auth_token, created_at, expiring_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertResetQuery);
            $stmt->bind_param("sssss", $username, $email, $auth_token, $created_at, $expiring_at);
            $stmt->execute();

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$siteLink = $protocol . "://" . $_SERVER['HTTP_HOST'] ;
            // Send email
            sendEmail($username, $email, $auth_token, $siteName, $sendFrom, $siteLink);

            // Set success response
            $response['status'] = 'success';
            $response['message'] = 'Password reset initiated. Check your email for instructions.';
        }
    } else {
        // User not found
        $response['status'] = 'error';
        $response['error'] = 'User not found';
    }
} else {
    // Missing username
    $response['status'] = 'error';
    $response['error'] = 'Missing username';
}

// Close the database connection
$stmt->close();
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit();



function sendEmail($username, $email, $auth_token, $siteName, $sendFrom, $siteLink) {
    global $stmpHost, $stmpUsername, $stmpPassword, $stmpPort, $stmpSecure;

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->SMTPDebug = SMTP::DEBUG_OFF; // Enable verbose debug output (change to SMTP::DEBUG_SERVER for debugging)
        $mail->isSMTP();
        $mail->Host = $stmpHost; // Your SMTP server address
        $mail->SMTPAuth = true;
        $mail->Username = $stmpUsername; // Your SMTP username
        $mail->Password = $stmpPassword; // Your SMTP password
        $mail->SMTPSecure = $stmpSecure; // Use TLS encryption (change to 'ssl' for SSL encryption)
        $mail->Port = $stmpPort; // SMTP port (587 for TLS, 465 for SSL)

        // Recipients
        $mail->setFrom($sendFrom, $siteName); // Sender's email and name
        $mail->addAddress($email, $username); // Recipient's email address and name

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = 'Message From ' . $siteName;
        $mail->Body = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <style>
        /* Email styles */
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        p {
            font-size: 16px;
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
        }


        .footer {
            text-align: center;
            color: #777;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <p>Hello User,</p><br>
        <p>Click This Link To Reset Your Password - $siteLink/resetpwd?auth=$auth_token<p><br>
        <p>
            Thank you for choosing $siteName.
        </p>
        <p>
            Best regards,<br>
             $siteName Team
        </p>
        <hr>
        <p class="footer">
            This email was sent to you in response to request to reset your password . &copy; 2023 $siteName. All rights reserved.
        </p>
    </div>
</body>
</html>
HTML;

        // Send the email
        if ($mail->send()) {
           return true;
        } else {
            return false; // Email sending failed
        }
    } catch (Exception $e) {
         error_log('Email sending failed: ' . $mail->ErrorInfo);
        return false; // Error occurred
    }
}

?>
