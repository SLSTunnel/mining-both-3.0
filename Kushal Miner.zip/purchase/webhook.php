<?php

require_once('../config/dbconfig.php');
include_once "../includes/settings.php";// Include your database connection file

// Read the raw JSON data from the request body
$json_data = file_get_contents("php://input");

// Check if any data was received
if (empty($json_data)) {
    echo json_encode(['status' => 'error', 'error' => 'No data received']);
    exit;
}

// Decode the JSON data
$data = json_decode($json_data, true);

// Check if the required parameters are present in the received JSON
if (
    isset($data['invoice_id']) &&
    isset($data['buyersEmail'])
) {
    // Retrieve the data from the JSON
    $invoice_id = $data['invoice_id'];
    $amount = $data['price'];
    $currency = $data['currency'];
    $productName = $data['productName'];
    $buyersEmail = $data['buyersEmail'];
    $depositmethod = "Crypto";

    // Get the current balance of the user from the users table
    $query = "SELECT user_id, username, upline FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);

    // ... (previous code)

    if ($stmt) {
        // Bind the parameter
        $stmt->bind_param("s", $buyersEmail);

        // Execute the query
        $stmt->execute();

        // Bind the results to variables
        $stmt->bind_result($user_id, $username, $upline);

        // Fetch the results
        $stmt->fetch();

        $stmt->close();

        if ($user_id) {
            // Get the plan_id from the plans table based on $productName
            $getPlanIdQuery = "SELECT id, duration FROM plans WHERE name = ?";
            $stmtGetPlanId = $conn->prepare($getPlanIdQuery);

            // ... (remaining code)

            if ($stmtGetPlanId) {
                // Bind the parameter
                $stmtGetPlanId->bind_param("s", $productName);

                // Execute the query
                $stmtGetPlanId->execute();

                // Bind the results to variables
                $stmtGetPlanId->bind_result($plan_id, $dur);

                // Fetch the results
                $stmtGetPlanId->fetch();

                $stmtGetPlanId->close();

                if ($plan_id) {
                    // Set the status as 'active'
                    $status = 'active';

                    // Set the start_date as the current date and time (GMT/UTC)
                    $start_date = gmdate('Y-m-d H:i:s');

                    // Calculate the end_date, e.g., add 1 day to the start_date
                    $end_date = date('Y-m-d H:i:s', strtotime($start_date . ' + '.$dur.' day'));

                    // Insert the data into the user_plans table
                    $insertUserPlansQuery = "INSERT INTO user_plans (plan_id, user_id, status, start_date, end_date) VALUES (?, ?, ?, ?, ?)";
                    $stmtInsertUserPlans = $conn->prepare($insertUserPlansQuery);

                    // ... (remaining code)

                    if ($stmtInsertUserPlans) {
                        // Bind parameters
                        $stmtInsertUserPlans->bind_param("sssss", $plan_id, $user_id, $status, $start_date, $end_date);

                        // Execute the query
                        $stmtInsertUserPlans->execute();

                        $stmtInsertUserPlans->close();
                        $bonus = $amount/$ref_bonus;

                        // Update balance in the users table for $upline
                        $updateBalanceQuery = "UPDATE users SET balance = balance + $bonus WHERE user_id = ?";
                        $stmtUpdateBalance = $conn->prepare($updateBalanceQuery);

                        if ($stmtUpdateBalance) {
                            // Bind parameter
                            $stmtUpdateBalance->bind_param("s", $upline);

                            // Execute the query
                            $stmtUpdateBalance->execute();

                            $stmtUpdateBalance->close();

                            // Insert data into another table (replace with your actual table name)
                            $insertUserDataQuery = "INSERT INTO user_deposits (user_id, plan_id, amount, status, created_at) VALUES (?, ?, ?, ?, ?)";
                            $stmtInsertUserData = $conn->prepare($insertUserDataQuery);

                            // ... (remaining code)
                            $stat = "success";

                            if ($stmtInsertUserData) {
                                // Set other parameters (replace with your actual values)
                               

                                // Bind parameters
                                $stmtInsertUserData->bind_param("iisss", $user_id, $plan_id, $amount, $stat, $start_date);

                                // Execute the query
                                $stmtInsertUserData->execute();

                                $stmtInsertUserData->close();

                                // Return a 200 response code
                                http_response_code(200);
                                echo json_encode(['status' => 'success']);
                            } else {
                                echo json_encode(['status' => 'error', 'error' => 'Error preparing statement for inserting user data']);
                            }
                        } else {
                            echo json_encode(['status' => 'error', 'error' => 'Error preparing statement for updating balance']);
                        }
                    } else {
                        echo json_encode(['status' => 'error', 'error' => 'Error preparing statement for inserting user plans']);
                    }
                } else {
                    echo json_encode(['status' => 'error', 'error' => 'Plan not found for the given product name']);
                }
            } else {
                echo json_encode(['status' => 'error', 'error' => 'Error preparing statement for getting plan id']);
            }
        } else {
            echo json_encode(['status' => 'error', 'error' => 'User not found for the given email']);
        }
    } else {
        // If any required parameter is missing, echo an error
        echo json_encode(['status' => 'error', 'error' => 'Incomplete parameters']);
    }
} else {
    // If any required parameter is missing, echo an error
    echo json_encode(['status' => 'error', 'error' => 'Incomplete paras']);
}
// ... (remaining code)
?>
