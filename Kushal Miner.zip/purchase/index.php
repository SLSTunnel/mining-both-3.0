<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: ../login');
    exit();
}
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // The "id" is present, you can proceed with your logic here
    $id = $_GET['id'];

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$siteLink = $protocol . "://" . $_SERVER['HTTP_HOST'] . "/";

require_once('../config/dbconfig.php');
require_once('../includes/settings.php');


$plansql = "SELECT name, price FROM plans WHERE id = '$id'";

// Execute the query
$planresult = $conn->query($plansql);

if ($planresult) {
    // Fetch the data as an associative array
    $plan = $planresult->fetch_assoc();
} else {
    echo "Error: " . $plansql . "<br>" . $conn->error;
}
$url = 'https://api.revelon.net/create_invoice';

$username = $_SESSION['user'];
$price = $plan["price"];
$productName = $plan["name"];
$query = "SELECT email FROM users WHERE username = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    // Bind the parameter
    $stmt->bind_param("s", $username);

    // Execute the query
    $stmt->execute();

    // Bind the results to variables
    $stmt->bind_result($email);
    // Fetch the results
    $stmt->fetch();

    $stmt->close();
} else {
    echo "Error preparing the SQL query: " . $conn->error;
}
if (!$email) {
  header("Location: $siteLink/dashboard?type=error&message=Email Not Set, Set Your Email First");
        exit;   
}
$url = 'https://api.revelon.net/create_invoice';
$headers = array('Content-Type' => 'application/json');
$data = json_encode(array(
    'apiKey' => $apiKey,
    'businessName' => $siteName,
    'redirectUrl' => $siteLink ."dashboard?type=buysuccess",
    'closeUrl' => $siteLink ."dashboard",
    'productName' => $productName,
    'currency' => $revelon_currency,
    'price' => $price,
    'payCoin' => $pay_coin,
    'notificationUrl' => $siteLink ."purchase/webhook.php",
    'buyersEmail' => $email
));

$ch = curl_init("https://api.revelon.net/create_invoice");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

// Execute the cURL request
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo "cURL error: " . curl_error($ch);
} else {
    // Parse the JSON response
    $responseData = json_decode($response, true);

    // Check if the status is "success"
    if (isset($responseData['status']) && $responseData['status'] === "success") {
        $invoiceId = $responseData['result']['invoice_id'];
        // Redirect to the invoice page
        header("Location: https://revelon.net/invoice?id=" . $invoiceId);
        exit;
    } else {
        // Display an error message
        echo "Error: " . $responseData['error'];
    }
}

// Close the cURL session
curl_close($ch);
} else {
    // Redirect to "../" if "id" is not received
    header("Location: ../");
    exit();
}
?>
