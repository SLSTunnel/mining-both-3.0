
<?php
include_once "../includes/header.php";
?>

<body>
<style>
    .settings-label {
        display: block;
        text-align: left;
        font-weight: bold;
        margin-bottom: 5px;
    }
    .desc {
         font-weight: normal;
        font-size: 12px;
    }
</style>
<div class="settings-form-container">
    <?php
if(isset($_GET["type"])) {
if ($_GET["type"] == "success" && $_GET["message"]) {
    echo '<div id="alert" class="success-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
} else if ($_GET["type"] == "error" && $_GET["message"]) {
    echo '<div id="alert" class="error-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
}
}
?>
    <form action="save.php" method="POST">
    <div class="settings-section">
        <div class="section-title">Main Settings</div>
        <label class="settings-label">Site Name</label>
        <input type="text" class="settings-input" name="site_name" value="<?php echo $siteName; ?>" placeholder="Site Name">
        <label class="settings-label">Site Keywords</label>
        <input type="text" class="settings-input" name="site_keywords" value="<?php echo $keywords; ?>" placeholder="Site Keywords">
        <label class="settings-label">Site Description</label>
        <textarea type="text" class="settings-input" name="site_description" placeholder="Site Description"><?php echo $description; ?></textarea>
    </div>

    <div class="settings-section">
        <div class="section-title">Limit Settings</div>
        <label class="settings-label">Min Withdrawal</label>
        <input type="number" class="settings-input" name="min_with" value="<?php echo $min_with; ?>" placeholder="Min Withdrawal">
        <label class="settings-label">Max Withdrawal</label>
        <input type="text" class="settings-input" name="max_with" value="<?php echo $max_with; ?>" placeholder="Max Withdrawal">
        <label class="settings-label">Affiliate Commission (%)</label>
        <input type="text" class="settings-input" name="ref_bonus" value="<?php echo $ref_bonus; ?>" placeholder="Affiliate Commission (%)">
    </div>

    <div class="settings-section">
        <div class="section-title">Currency Settings</div>
        <label class="settings-label">Currency Name</label>
        <input type="text" class="settings-input" name="currency" value="<?php echo $currency; ?>" placeholder="Currency Name">
        <label class="settings-label">Currency Symbol</label>
        <input type="text" class="settings-input" name="curr_symbol" value="<?php echo $curr_symbol; ?>" placeholder="Currency Symbol">
        <label class="settings-label">Wallet Address Min Chars</label>
        <input type="text" class="settings-input" name="min_wallet" value="<?php echo $min_wallet; ?>" placeholder="Wallet Address Min Chars">
        <label class="settings-label">Wallet Address Max Chars</label>
        <input type="text" class="settings-input" name="max_wallet" value="<?php echo $max_wallet; ?>" placeholder="Wallet Address Max Chars">
        <label class="settings-label">Blockchain Tracking Url</label>
        <input type="text" class="settings-input" name="blockchain_url" value="<?php echo $blockchain_url; ?>" placeholder="Blockchain Tracking Url">
    </div>

    <div class="settings-section">
        <div class="section-title">Revelon Settings</div>
        <label class="settings-label">Revelon Currency</label>
        <input type="text" class="settings-input" name="revelon_currency" value="<?php echo $revelon_currency; ?>" placeholder="Revelon Currency">
        <label class="settings-label">Payment Coin <p class="desc">(This is the coin which users will pay with)</p></label>
        
        <input type="text" class="settings-input" name="revelon_paycoin" value="<?php echo $pay_coin; ?>" placeholder="Payment Coin">
        <label class="settings-label">Revelon Api Key</label>
        <input type="text" class="settings-input" name="revelon_apiKey" value="<?php echo $apiKey; ?>" placeholder="Revelon API Key">
    </div>

    <div class="settings-section">
        <div class="section-title">Email Settings</div>
        <label class="settings-label">SMTP Host</label>
        <input type="text" class="settings-input" name="stmp_host" value="<?php echo $stmpHost; ?>" placeholder="SMTP Host">
        <label class="settings-label">SMTP Port</label>
        <input type="text" class="settings-input" name="stmp_port" value="<?php echo $stmpPort; ?>" placeholder="SMTP Port">
        <label class="settings-label">SMTP Secure  <p class="desc">(SSL, TLS, STARTlS)</p></label>
        <input type="text" class="settings-input" name="stmp_secure" value="<?php echo $stmpSecure; ?>" placeholder="SMTP Secure">
        <label class="settings-label">SMTP Username</label>
        <input type="text" class="settings-input" name="stmp_username" value="<?php echo $stmpUsername; ?>" placeholder="SMTP Username">
        <label class="settings-label">Sender Email</label>
        <input type="text" class="settings-input" name="sender_email" value="<?php echo $sendFrom; ?>" placeholder="SMTP Sender Email">
        <label class="settings-label">SMTP Password</label>
        <input type="password" class="settings-input" name="stmp_password" value="<?php echo $stmpPassword; ?>" placeholder="SMTP Password">
    </div>

    <button type="submit" class="submit-button"><i class="fas fa-save"></i> Save</button>
</form>
</div>
<script>
        function hideAlert() {
    var successAlert = document.getElementById("alert");
    if (successAlert) {
        successAlert.style.display = "none";
    }
}
</script>
</body>
</html>
