<?php
session_start();
if (isset($_SESSION['admin'])) {
    header('Location: dashboard');
    exit(); // Ensure that no further code is executed after the redirect
} 
?>
<?php
include_once "../includes/settings.php";
?>

 <style>
      .login-container {
      width: 300px;
      margin: 10% auto;
      background-color: #fff;
      border-radius: 15px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .login-title {
      font-size: 1.5em;
      margin-bottom: 20px;
    }

    .login-input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      box-sizing: border-box;
    }

    .login-button {
      background-color: #3498db;
      color: #fff;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .login-description {
      font-size: 0.9em;
      color: #777;
    }
    
 </style>
 <title>Admin Panel Login</title>
<body>

  <div class="login-container">
        <div class="login-title">Reset Password</div>
<br>
    <form method="POST" action="reset.php">
      <input class="login-input" name="username" type="text" placeholder="Username" required>

      <button class="login-button" type="submit">Go</button>
    </form>

    <p class="login-description">Enter your username an email will be sent to you</p>
    
  </div>

</body>
</html>
