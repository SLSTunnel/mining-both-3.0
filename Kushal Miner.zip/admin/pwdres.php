<?php
include '../config/dbconfig.php';

// Start the session
session_start();

// Check if 'auth' is provided through GET
if (isset($_GET['auth'])) {
    $authToken = $_GET['auth'];

    // Check if the auth token exists in the password_reset table
    $checkAuthQuery = "SELECT * FROM password_reset WHERE auth_token = ?";
    $stmt = $conn->prepare($checkAuthQuery);
    $stmt->bind_param("s", $authToken);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Auth token exists, check expiration
        $row = $result->fetch_assoc();
        $expiryDate = $row['expiring_at'];
        $username = $row['username'];
        $currentTime = gmdate('Y-m-d H:i:s');

        if ($currentTime > $expiryDate) {
            // Token has expired, redirect to ../
            header('Location: ../');
            exit();
        }
        // Auth token exists and has not expired, stay on the page
    } else {
        // Auth token does not exist, redirect to ../
        header('Location: ../');
        exit();
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
} else {
    // 'auth' not provided, redirect to ../
    header('Location: ../');
    exit();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }

        .form-container {
            max-width: 400px;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            background-color: #fff;
        }

        .form-container label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .form-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Password Reset</h2>
        <form action="pwwdres.php" method="POST">
            
<input type="hidden" name="username" value="<?php echo $username;?>">
            <label for="new_password">New Password</label>
            <input type="password" id="new_password" name="new_password" required>

            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
