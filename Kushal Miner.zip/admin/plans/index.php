
<?php
include_once "../includes/header.php";
$sql = "SELECT * FROM plans";
$result = $conn->query($sql);

// Close the database connection
$conn->close();
?>
<body>

<div class="plans-container">
    <div class="plans-header">Below are your Current Plans</div>
   <?php
   if (isset($_SESSION['success_message'])) {
    ?>
    <div class="success-box">
        <div class="success-message">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the success message from the session
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    ?>
    <div class="error-box">
        <div class="error-message">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the error message from the session
    unset($_SESSION['error_message']);
}
?>
    <button onclick="location.href='create.php'" class="add-plan"><i class="fas fa-plus"></i> Add Plan</button>
<div class="p-table">
    <table class="plans-table">
        <thead>
            <tr>
                <th>Plan Name</th>
                <th>Coins Daily</th>
                <th>Version</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
           <?php
        // Loop through the result set and display each row in the table
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['name'] . '</td>';
            echo '<td>' . $row['amount_daily'] . '</td>';
            echo '<td>' . $row['version'] . '</td>';
            echo '<td>' . $row['price'] . '</td>';
            echo '<td class="action-plan">';
            echo '<a href="edit.php?id='. $row["id"] .'"><button class="edit" ><i class="fas fa-edit"></i></button></a>';
            echo '<a href="delete.php?id='. $row["id"] .'"><button class="delete" ><i class="fas fa-trash-alt"></i></button></a>';
            echo '</td>';
            echo '</tr>';
        }
        ?>
        </tbody>
    </table>
    </div>
</div>

<?php
include_once "../includes/footer.php";
?>
</body>
</html>


