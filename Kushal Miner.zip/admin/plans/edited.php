<?php
session_start();

include_once "../../config/dbconfig.php";

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $id = $_POST['plan_id'];
    $plan_name = $_POST['plan_name'];
    $plan_price = $_POST['plan_price'];
    $plan_duration = $_POST['plan_duration'];
    $version = $_POST['version'];
    $speed = $_POST['speed'];
    $amount_daily = $_POST["amount_daily"];
    $image = "none";
if ($plan_price <= 0) {
    $_SESSION['error_message'] = "Price can't be zero.";
    header("Location: edit.php");
    exit();
}
if ($amount_daily <= 0) {
    $_SESSION['error_message'] = "Amount Daily can't be zero.";
    header("Location: edit.php");
    exit();
}
    // Update data in the plans table using prepared statements
    $sql = "UPDATE plans 
            SET name = ?, 
                price = ?, 
                duration = ?, 
                version = ?, 
                Speed = ?, 
                image = ?, 
                amount_daily = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("sssssssi", $plan_name, $plan_price, $plan_duration, $version, $speed, $image, $amount_daily, $id);

    if ($stmt->execute()) {
        // Redirect to index.php after successful update
        header('Location: index.php');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();

?>
