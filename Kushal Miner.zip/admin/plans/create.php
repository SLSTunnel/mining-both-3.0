
<?php
include_once "../includes/header.php";
?>
<body>

<div class="plan-form-container">
    <?php
   if (isset($_SESSION['success_message'])) {
    ?>
    <div class="success-box">
        <div class="success-message">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the success message from the session
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    ?>
    <div class="error-box">
        <div class="error-message">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the error message from the session
    unset($_SESSION['error_message']);
}
?>
   <form method="POST" action="save.php">
    <label class="label">Plan Name</label>
    <input type="text" name="plan_name" class="plan-input" placeholder="Plan Name" required>
    <label class="label">Plan Price</label>
    <input type="text" name="plan_price" class="plan-input" placeholder="Plan Price" required>
    <label class="label">Plan Duration (Days)</label>
    <input type="text" name="plan_duration" class="plan-input" placeholder="Plan Duration (Days)" required>
    <label class="label">Earning Amount Daily</label>
    <input type="text" name="amount_daily" class="plan-input" placeholder="Amount Daily" required>
    <label class="label">Plan Version</label>
    <input type="text" name="version" class="plan-input" placeholder="Version" required>
    <label class="label">Plan Speed (H/S)</label>
    <input type="text" name="speed" class="plan-input" placeholder="Speed" required>
    <button type="submit" class="save-plan"><i class="fas fa-save"></i> Save</button>
</form>

</div>

<?php
include_once "../includes/footer.php";
?>
</body>
</html>
