<?php
session_start();
include_once "../../config/dbconfig.php";
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $plan_name = $_POST['plan_name'];
    $plan_price = $_POST['plan_price'];
    $plan_duration = $_POST['plan_duration'];
    $version = $_POST['version'];
    $speed = $_POST['speed'];
    $amount_daily = $_POST["amount_daily"];
    $image = "none";
if ($plan_price <= 0) {
    $_SESSION['error_message'] = "Price can't be zero.";
    header("Location: create.php");
    exit();
}
if ($amount_daily <= 0) {
    $_SESSION['error_message'] = "Amount Daily can't be zero.";
    header("Location: create.php");
    exit();
}
    // Insert data into the plans table
    $sql = "INSERT INTO plans (name, price, duration, version, Speed, image, amount_daily) VALUES ('$plan_name', $plan_price, $plan_duration, '$version', '$speed', '$image', '$amount_daily')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to index.php after successful save
        header('Location: index.php');
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();

?>