
<?php
include_once "../includes/header.php";


// Check if the 'id' parameter is present in the GET request
if (isset($_GET['id'])) {
    // Get the 'id' value from the GET request
    $id = $_GET['id'];

    // Query to select data for the specified 'id'
    $sql = "SELECT name, price, duration, amount_daily, version, speed FROM plans WHERE id = $id";

    // Execute the query
    $result = $conn->query($sql);

    // Check if the query was successful
    if ($result) {
        // Fetch the data as an associative array
        $row = $result->fetch_assoc();

        // Assign values to variables
        $name = $row['name'];
        $price = $row['price'];
        $duration = $row['duration'];
        $amount_daily = $row['amount_daily'];
        $version = $row['version'];
        $speed = $row['speed'];
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // If 'id' is not present in the GET request, handle the situation accordingly
    echo "ID not provided in the request.";
}

// Close the database connection
$conn->close();

?>
<body>

<div class="plan-form-container">
   <form method="POST" action="edited.php">
       <?php
   if (isset($_SESSION['success_message'])) {
    ?>
    <div class="success-box">
        <div class="success-message">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the success message from the session
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    ?>
    <div class="error-box">
        <div class="error-message">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the error message from the session
    unset($_SESSION['error_message']);
}
?>
    <label class="label"=>Id</label>
    <input type="text" name="plan_id" class="plan-input" value="<?php echo $id;?>">
    <label class="label">Name</label>
    <input type="text" name="plan_name" class="plan-input" value="<?php echo $name;?>">
    <label class="label">Plan Price</label>
    <input type="text" name="plan_price" class="plan-input" value="<?php echo $price;?>">
    <label class="label">Plan Duration (Days)</label>
    <input type="text" name="plan_duration" class="plan-input" value="<?php echo $duration;?>">
    <label class="label">Earning Amount Daily</label>
    <input type="text" name="amount_daily" class="plan-input" value="<?php echo $amount_daily;?>">
    <label class="label">Plan Version</label>
    <input type="text" name="version" class="plan-input" value="<?php echo $version;?>">
    <label class="label">Plan Speed (H/S)</label>
    <input type="text" name="speed" class="plan-input" value="<?php echo $speed;?>">
    <button type="submit" class="save-plan"><i class="fas fa-save"></i> Save</button>
</form>
</div>

<?php
include_once "../includes/footer.php";
?>
</body>
</html>
