<?php
// Include your database configuration file (dbconfig.php)
include_once "../../config/dbconfig.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have the necessary form field names, adjust them accordingly
    $username = $_POST["username"];
    $amount = $_POST["amount"];
    $txHash = $_POST["txHash"];
    $status = $_POST["status"];
    $created_at = $_POST["created_at"];

    // Assuming you have a primary key for the withdrawal record, adjust it accordingly
    $id = $_POST["id"];

    // Update the record in the withdrawals table
    $updateQuery = "UPDATE withdrawals SET username = ?, amount = ?, txHash = ?, status = ?, created_at = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("sdsssi", $username, $amount, $txHash, $status, $created_at, $id);

        // Execute the query
        $stmt->execute();

        // Close the statement
        $stmt->close();
    } else {
        // Handle query error
        echo 'Error preparing statement: ' . $conn->error;
    }

    // Close the database connection
    $conn->close();

    // Redirect to the withdrawals page
    header("Location: ../withdrawals");
    exit();
} else {
    // If the form is not submitted via POST, redirect or handle accordingly
 echo "Not Post"
;}
?>
