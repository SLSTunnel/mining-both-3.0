<?php
include_once "../includes/header.php";


// Check if the 'id' parameter is present in the GET request
if (isset($_GET['id'])) {
    // Get the 'id' value from the GET request
    $id = $_GET['id'];

    // Query to select data for the specified 'id'
    $sql = "SELECT username, amount, txHash, status, created_at FROM withdrawals WHERE id = $id";

    // Execute the query
    $result = $conn->query($sql);

    // Check if the query was successful
    if ($result) {
        // Fetch the data as an associative array
        $row = $result->fetch_assoc();

        // Assign values to variables
        $username = $row['username'];
        $amount = $row['amount'];
        $txHash = $row['txHash'];
        $status = $row['status'];
        $created_at = $row['created_at'];
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // If 'id' is not present in the GET request, handle the situation accordingly
    echo "ID not provided in the request.";
}

// Close the database connection
$conn->close();

?>

<body>

<div class="wedit-form-container">
    <form class="wedit-form" action="save.php" method="POST">
        <input name="id" value="<?php echo $id; ?>" type="hidden">
    <label class="label">Wallet Address</label>
        <input type="text" class="wedit-input" name="username" value="<?php echo $username; ?>" readonly>
    <label class="label">Amount</label>
        <input type="text" class="wedit-input" name="amount" value="<?php echo $amount; ?>" readonly>
    <label class="label">Tx Hash</label>
        <input type="text" class="wedit-input" name="txHash" placeholder="Tx Hash" value="<?php echo $txHash ?>" > 
    <label class="label">Status</label>
        <select name="status" class="dropdown">
            <option value="<?php echo $status; ?>"><?php echo $status; ?></option>
            <option value="success">Completed</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
        </select>
    <label class="label">Date</label>
        <input name="created_at" type="datetime-local" class="time-edit" value="<?php echo $created_at; ?>">
        <button type="submit" class="wedit-button"><i class="fas fa-check"></i> Submit</button>
    </form>
</div>

<?php
include_once "../includes/footer.php";
?>
</body>
</html>
