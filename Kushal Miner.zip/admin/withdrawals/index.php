<?php
include_once "../includes/header.php";
$sql = "SELECT * FROM withdrawals WHERE status = 'pending' ";
$result = $conn->query($sql);

// Close the database connection
$conn->close();
?>
<body>

<div class="withdrawal-history-container">
    <h2>Withdrawal History</h2>

    <table class="withdrawal-history-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User Wallet</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
          
            <?php
       if ($result->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['username'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '<td class="action-withdraw">';
        echo '<a href="edit.php?id=' . $row["id"] . '"><button class="edit"><i class="fas fa-edit"></i></button></a>';
        echo '<a href="delete.php?id=' . $row["id"] . '"><button class="delete"><i class="fas fa-trash-alt"></i></button></a>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="6">No withdrawals</td></tr>';
}
        ?>
        
    


            <!-- Add more withdrawal history data rows as needed -->
        </tbody>
    </table>
</div>
<?php
include_once "../includes/footer.php";
?>
</body>
</html>
