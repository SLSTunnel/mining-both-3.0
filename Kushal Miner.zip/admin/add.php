<?php
// Include your database configuration file (dbconfig.php)
require_once('../config/dbconfig.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Retrieve form data
    $username = "ademola";
    $password = "ademola12345";
    $email = "odogiyon@gmail.com";
    $status = "active";

    // alidate and sanitize input as needed

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the admin table
    $query = "INSERT INTO admins (username, password, email, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("ssss", $username, $hashedPassword, $email, $status);

        // Execute the query
        $stmt->execute();

        // Close the statement
        $stmt->close();

        echo 'User added successfully!';
    } else {
        // Handle database error
        echo 'Error preparing statement for inserting data.';
    }

    // Close the database connection
    $conn->close();
}
?>
<!-- Add your HTML form here -->
