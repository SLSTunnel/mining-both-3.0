<?php
include_once "../includes/header.php";
$sql = "SELECT * FROM support_tickets WHERE status = 'pending' ";
$result = $conn->query($sql);

// Close the database connection
$conn->close();
?>

<body>

<div class="support-table-container">
    <?php
if(isset($_GET["type"])) {
if ($_GET["type"] == "success" && $_GET["message"]) {
    echo '<div id="alert" class="success-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
} else if ($_GET["type"] == "error" && $_GET["message"]) {
    echo '<div id="alert" class="error-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
}
}
?>
   
    <h2>Support Tickets</h2>

    <table class="support-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Subject</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            
            <?php
       if ($result->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $row['subject'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '<td class="support-buttons">';
        echo '<a href="edit.php?id=' . $row["id"] . '"><button class="edit"><i class="fas fa-edit"></i></button></a>';
        echo '<a href="delete.php?id=' . $row["id"] . '"><button class="delete"><i class="fas fa-trash-alt"></i></button></a>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="6">No Tickets Yet</td></tr>';
}
        ?>
            <!-- Add more support ticket data rows as needed -->
        </tbody>
    </table>
</div>

</body>
</html>
