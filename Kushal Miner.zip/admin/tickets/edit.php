<?php
include_once "../includes/header.php";


// Check if the 'id' parameter is present in the GET request
if (isset($_GET['id'])) {
    // Get the 'id' value from the GET request
    $id = $_GET['id'];

    // Query to select data for the specified 'id'
    $sql = "SELECT name, email, subject, message, status, created_at FROM support_tickets WHERE id = $id";

    // Execute the query
    $result = $conn->query($sql);

    // Check if the query was successful
    if ($result) {
        // Fetch the data as an associative array
        $row = $result->fetch_assoc();

        // Assign values to variables
        $name = $row['name'];
        $email = $row['email'];
        $subject = $row['subject'];
        $message = $row['message'];
        $status = $row['status'];
        $created_at = $row['created_at'];
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // If 'id' is not present in the GET request, handle the situation accordingly
    echo "ID not provided in the request.";
}

// Close the database connection
$conn->close();

?>
<style>
    .settings-label {
        display: block;
        text-align: left;
        font-weight: bold;
        margin-bottom: 2px;
    }
    .desc {
         font-weight: normal;
        font-size: 12px;
    }
</style>
<div class="edit-ticket-form-container">
    
    <h2>Edit Support Ticket</h2>

   <form method="POST" action="save.php" class="edit-ticket-form">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <label class="settings-label">Name</label>
    <input type="text" class="support-input" name="name" placeholder="Name" value="<?php echo $name; ?>">
    <label class="settings-label">Email</label>
    <input type="text" class="support-input" name="email" placeholder="Email" value="<?php echo $email; ?>">
    <label class="settings-label">Subject</label>
    <input type="text" class="support-input" name="subject" placeholder="Subject" value="<?php echo $subject; ?>">
    <label class="settings-label">Message</label>
    <textarea class="text-area" name="message" placeholder="Message"><?php echo $message; ?></textarea>

    <select class="dropdown" name="status">
        <option value="<?php echo $status; ?>"><?php echo $status; ?></option>
        <option value="replied">Completed</option>
        <option value="pending">Pending</option>
    </select>
    <label class="settings-label">Reply</label>
    <textarea class="text-area" name="reply" placeholder="Reply"></textarea>
    <button type="submit" class="submit-button"><i class="fas fa-check"></i> Submit</button>
</form>

</div>

</body>
</html>
