<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer classes
require '../../phpmailer/src/PHPMailer.php';
require '../../phpmailer/src/SMTP.php';
require '../../phpmailer/src/Exception.php';

// Include stmp configuration
require '../../includes/settings.php';

// Include the database configuration file
include '../../config/dbconfig.php';

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $id = $_POST['id'];
    $status = $_POST['status'];
    $name = $_POST['name'];
    $reply = $_POST['reply'];

    // Update status in the support tickets table
    $updateStatusQuery = "UPDATE support_tickets SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($updateStatusQuery);
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();

    // Check if reply is provided
    if (!empty($reply)) {
        // Call send_reply function
        send_reply($reply, $_POST['email'], $name, $siteName);
    }

    // Close the database connection
    $stmt->close();
    $conn->close();

    // Redirect to the appropriate page after processing the form
    header("Location: ./?type=success&message=Changes Updated");
    exit();
} else {
    // If form data is not submitted, redirect to an error page or home page
    header("Location: ./?type=error&message=Error");
    exit();
}

function send_reply($reply, $email, $name, $siteName) {
    global $stmpHost, $stmpUsername, $stmpPassword, $stmpPort, $stmpSecure;

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = SMTP::DEBUG_OFF; // Enable verbose debug output (change to SMTP::DEBUG_SERVER for debugging)
        $mail->isSMTP();
        $mail->Host = $stmpHost; // Your SMTP server address
        $mail->SMTPAuth = true;
        $mail->Username = $stmpUsername; // Your SMTP username
        $mail->Password = $stmpPassword; // Your SMTP password
        $mail->SMTPSecure = $stmpSecure; // Use TLS encryption (change to 'ssl' for SSL encryption)
        $mail->Port = $stmpPort; // SMTP port (587 for TLS, 465 for SSL)

        // Recipients
        $mail->setFrom($stmpUsername, $siteName); // Sender's email and name
        $mail->addAddress($email, $name); // Recipient's email address and name

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = 'Message From ' . $siteName;
        $mail->Body = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <style>
        /* Email styles */
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        p {
            font-size: 16px;
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
        }


        .footer {
            text-align: center;
            color: #777;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <p>Hello $name,</p><br>
        <p>$reply<p><br>
        <p>
            Thank you for choosing $siteName.
        </p>
        <p>
            Best regards,<br>
             $siteName Team
        </p>
        <hr>
        <p class="footer">
            This email was sent to you in response to your support ticket. &copy; 2023 $siteName. All rights reserved.
        </p>
    </div>
</body>
</html>
HTML;

        // Send the email
        if ($mail->send()) {
           return true;
        } else {
            return false; // Email sending failed
        }
    } catch (Exception $e) {
         error_log('Email sending failed: ' . $mail->ErrorInfo);
        return false; // Error occurred
    }
}

?>
