
<?php
include_once "../includes/header.php";
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Close the database connection
$conn->close();
?>

<body>

<div class="users-table-container">
    <table class="users-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Username</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
           <?php
        // Loop through the result set and display each row in the table
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['user_id'] . '</td>';
            echo '<td>' . $row['username'] . '</td>';
            echo ' <td class="action-users">';
            echo '<a href="view.php?id='.$row['id'].'"<button class="view-users"><i class="fas fa-eye"></i> View</button></a>';
            echo '</td>';
            echo '</tr>';
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
