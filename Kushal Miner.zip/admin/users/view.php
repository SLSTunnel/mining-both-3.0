<?php
include_once "../includes/header.php";

// Assuming $id is the variable containing the specific user ID you want to retrieve
$id = $_GET["id"]; // Replace with your actual user ID

// Initialize variables
$username = '';
$email = '';
$balance = 0;
$user_id = 0;

// Query to get user information based on ID
$query = "SELECT username, email, balance, user_id, upline FROM users WHERE id = ?";

// Prepare the statement
$stmt = $conn->prepare($query);

if ($stmt) {
    // Bind the parameter
    $stmt->bind_param("i", $id);

    // Execute the query
    $stmt->execute();

    // Bind the results to variables
    $stmt->bind_result($username, $email, $balance, $user_id, $upline);

    // Fetch the result
    $stmt->fetch();

    // Close the statement
    $stmt->close();
} else {
    // Handle query error
    echo 'Error preparing statement: ' . $conn->error;
}

$withsql = "SELECT * FROM withdrawals WHERE id = '$username' ORDER BY created_at DESC"; 
$withresult = $conn->query($withsql);


$depsql = "SELECT * FROM user_deposits WHERE user_id = '$user_id' ORDER BY created_at DESC";
$depresult = $conn->query($depsql);

$refsql = "SELECT * FROM users WHERE upline = '$user_id' ORDER BY joined_at DESC";
$refresult = $conn->query($refsql);
// Close the database connection
$conn->close();

?>


<div class="user-details-container">
    <div class="basic-details">
        <div class="odd">Username: <?php echo $username; ?></div>
        <div class="even">Email: <?php echo $email; ?></div>
        <div class="odd">User ID: <?php echo $user_id; ?></div>
        <div class="even">Upline ID: <?php echo $upline; ?></div>
        <div class="odd">Balance: <?php echo $balance; ?> <?php echo $curr_symbol; ?></div>
    </div>

  
</div>

<div class="history-table-container">
    <h2 class="left">Withdrawals</h2>
    <table class="history-table">
        <thead>
            <tr>
                <th>Date</th>
                    <th>Amount</th>
                    <th>txId</th>
                    <th>Status</th>
            </tr>
        </thead>
        <tbody>
                 
                
            <?php
       if ($withresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $withresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        echo '<td>' . $row['txHash'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No withdrawals Yet</td></tr>';
}
        ?>
            <!-- Add more history data rows as needed -->
        </tbody>
    </table>
</div>


<div class="history-table-container">
    <h2 class="left">Deposits</h2>
    <table class="history-table">
        <thead>
           <tr><th>User Id</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
        </thead>
        <tbody>
                 
                
                              
            <?php
       if ($depresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $depresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['user_id'] . '</td>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No Deposits Yet</td></tr>';
}
        ?>
            <!-- Add more history data rows as needed -->
        </tbody>
    </table>
</div>
<div class="history-table-container">
    <h2 class="left">Referrals</h2>
    <table class="history-table">
        <thead>
            <tr>
                <th>Name</th>
                    <th>User ID</th>
                    <th>Date Joined</th>
            </tr>
        </thead>
        <tbody>
                 
                
                                        
            <?php
       if ($refresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $refresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['username'] . '</td>';
        echo '<td>' . $row['user_id'] . '</td>';
        echo '<td>' . $row['joined_at'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No Referrals Yet</td></tr>';
}
        ?>
            <!-- Add more history data rows as needed -->
        </tbody>
    </table>
</div>
</body>
</html>
