<?php
// Include your database configuration file (dbconfig.php)
require_once('../../config/dbconfig.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];
    $status = "active";

    // alidate and sanitize input as needed

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the admin table
    $query = "INSERT INTO admins (username, password, email, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("ssss", $username, $hashedPassword, $email, $status);

        // Execute the query
        $stmt->execute();

        // Close the statement
        $stmt->close();

      header('Location: index.php');
        exit;
    } else {
        // Handle database error
       $_SESSION['error_message'] = "Error preparing statement for inserting data.";
    header("Location: index.php");
    exit(); 
    }

    // Close the database connection
    $conn->close();
}
?>
