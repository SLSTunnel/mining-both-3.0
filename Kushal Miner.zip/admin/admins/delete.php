<?php
include_once "../../config/dbconfig.php";

// Check if the 'id' parameter is present in the GET request
if (isset($_GET['id'])) {
    // Get the 'id' value from the GET request
    $id = $_GET['id'];

    // Delete the row from the plans table where id matches
    $sql = "DELETE FROM admins WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Redirect to index.php after successful deletion
        header('Location: index.php');
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // If 'id' is not present in the GET request, handle the situation accordingly
    echo "ID not provided in the request.";
}

// Close the database connection
$conn->close();
?>
