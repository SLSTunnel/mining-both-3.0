
<?php
include_once "../includes/header.php";
?>
<body>

<div class="plan-form-container">
   <form method="POST" action="save.php">
          <?php
   if (isset($_SESSION['success_message'])) {
    ?>
    <div class="success-box">
        <div class="success-message">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the success message from the session
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    ?>
    <div class="error-box">
        <div class="error-message">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
    </div>
    <?php
    // Clear the error message from the session
    unset($_SESSION['error_message']);
}
?>
    <label class="label">Username</label>
    <input type="text" name="username" class="plan-input" placeholder="User Name">
    <label class="label">Email</label>
    <input type="text" name="email" class="plan-input" placeholder="Email">
    <label class="label">Password</label>
    <input type="text" name="password" class="plan-input" placeholder="password">
    <button type="submit" class="save-plan"><i class="fas fa-save"></i> Save</button>
</form>

</div>

<?php
include_once "../includes/footer.php";
?>
</body>
</html>
