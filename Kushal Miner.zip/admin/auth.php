<?php
// Include your database configuration file (dbconfig.php)
require_once('../config/dbconfig.php');

// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validate and sanitize input as needed

    // Get the hashed password from the admin table
    $query = "SELECT password FROM admins WHERE username = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        // Bind the parameter
        $stmt->bind_param("s", $username);

        // Execute the query
        $stmt->execute();

        // Bind the result to a variable
        $stmt->bind_result($hashedPassword);

        // Fetch the result
        $stmt->fetch();

        // Close the statement
        $stmt->close();

        if ($hashedPassword && password_verify($password, $hashedPassword)) {
            // Password is correct, set session admin and redirect to dashboard
            $_SESSION['admin'] = $username;
            header('Location: dashboard');
            exit();
        } else {
            // Incorrect password, show an alert
            echo '<script>alert("Incorrect username or password.");</script>';
        }
    } else {
        // Handle database error
        echo '<script>alert("Database error.");</script>';
    }

    // Close the database connection
    $conn->close();
}
?>
<!-- Add your HTML form here -->
