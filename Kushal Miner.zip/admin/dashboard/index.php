<?php
include_once "../includes/header.php";

$numUsers = 0.00000;
$numTickets = 0.00000;
$numPlans = 0.00000;
$deposits = 0.000000;
$pendWiths = 0;
$withdrawals = 0.00000;
// Query to get the number of rows in each table
$query = "SELECT
    (SELECT COUNT(*) FROM users) as numUsers,
    (SELECT COUNT(*) FROM support_tickets WHERE status = 'pending') as numTickets,
    (SELECT COUNT(*) FROM withdrawals WHERE status = 'pending') as pendWiths,
    (SELECT COUNT(*) FROM plans) as numPlans";

// Execute the query
$result = $conn->query($query);

// Check if the query was successful
if ($result) {
    // Fetch the result row
    $row = $result->fetch_assoc();

    // Assign values to variables
    $numUsers = $row['numUsers'];
    $numTickets = $row['numTickets'];
    $pendWiths = $row['pendWiths'];
    $numPlans = $row['numPlans'];

    // Free the result set
    $result->free();
} else {
    // Handle query error
    echo 'Error executing the query: ' . $conn->error;
}



$withquery = "SELECT SUM(amount) as total FROM withdrawals WHERE status = 'success'";
$withresult = mysqli_query($conn, $withquery);

if ($withresult) {
    // Fetch the result as an associative array
    $withs = mysqli_fetch_assoc($withresult);

    // Check if there is a result
    if ($withs['total'] !== null) {
        // Set the total withdrawals
        $withdrawals = $withs['total'];
    }
} else {
    // Handle the query error if needed
    echo "Error: " . mysqli_error($conn);
}


$depoquery = "SELECT SUM(amount) as total FROM user_deposits WHERE status = 'success'";
$deporesult = mysqli_query($conn, $depoquery);

if ($deporesult) {
    // Fetch the result as an associative array
    $depos = mysqli_fetch_assoc($deporesult);

    // Check if there is a result
    if ($depos['total'] !== null) {
        // Set the total withdrawals
        $deposits = $depos['total'];
    }
} else {
    // Handle the query error if needed
    echo "Error: " . mysqli_error($conn);
}




$profits = $deposits - $withdrawals
;// Close the database connection
$conn->close();



?>

<body>
<style>
    .spp {
        margin-left: 200px;
    }
    
         @media (max-width: 768px) {
             .spp {
        margin-left: 20px;
    }
         }
</style>
<div class="dashboard-container spp">
    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-clock"></i></div>
        <div class="stat-value"><?php echo $pendWiths; ?></div>
        <div class="stat-label">Pending Withdrawals</div>
    </div>

    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-ticket-alt"></i></div>
        <div class="stat-value"><?php echo $numTickets; ?></div>
        <div class="stat-label">Unread Tickets</div>
    </div>

    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-users"></i></div>
        <div class="stat-value"><?php echo $numUsers; ?></div>
        <div class="stat-label">Total Users</div>
    </div>

    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-tasks"></i></div>
        <div class="stat-value"><?php echo $numPlans; ?></div>
        <div class="stat-label">Total Plans</div>
    </div>

    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-money-bill"></i></div>
        <div class="stat-value"><?php echo $deposits; ?> <?php echo $curr_symbol; ?></div>
        <div class="stat-label">Total Deposit</div>
    </div>

    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-money-check-alt"></i></div>
        <div class="stat-value"><?php echo $withdrawals; ?> <?php echo $curr_symbol; ?></div>
        <div class="stat-label">Total Withdrawals</div>
    </div>

    <div class="dashboard-stat">
        <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
        <div class="stat-value"><?php echo $profits; ?> <?php echo $curr_symbol; ?></div>
        <div class="stat-label">Total Profits</div>
    </div>
</div>
<br>
<br>
<?php
include_once "../includes/footer.php";
?>
</body>
</html>
