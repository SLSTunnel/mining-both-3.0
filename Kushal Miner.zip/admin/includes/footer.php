
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
        }

        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .footer-text {
            display: block;
            justify-content: space-between;
            max-width: 1200px;
            margin: 0 auto;
        }

        .copyright {
            font-size: 14px;
        }

        .designed-by {
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="footer">
    <div class="footer-text">
        <div class="copyright">All Right Reserved By Kushal Techs &copy; 2023</div>
        <div class="designed-by">Designed By Kushal</div>
    </div>
</div>
