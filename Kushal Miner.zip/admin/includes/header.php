<?php

// Start the session
session_start();

// Check if the admin session is not set
if (!isset($_SESSION['admin'])) {
    // Redirect to the home page or any other desired location
    header('Location: ../');
    exit(); // Make sure to stop script execution after redirection
}


$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$siteLink = $protocol . "://" . $_SERVER['HTTP_HOST'] ;

include_once "../../config/dbconfig.php";
include_once "../../includes/settings.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Administrator</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $siteLink; ?>/admin/css/style.css"
</head>
<body>

<div class="admin-header">
    <button class="opn-sh left" onclick="show()"><i class="fas fa-bars switch-btn"></i></button>
    <h2 class="t-header">Admin Panel</h2>
</div>
<div id="admin-menu" class="admin-menu">
  <button class="cls-sh right" onclick="hide()"><i class="fas fa-times switch-btn"></i></button>
   <a href="<?php echo $siteLink; ?>/admin/dashboard"><button class="menu-button"><i class="fas fa-chart-pie"></i>Home</button></a> 
   <a href="<?php echo $siteLink; ?>/admin/plans"><button class="menu-button"><i class="fas fa-chart-pie"></i> Plan Management</button></a> 
   <a href="<?php echo $siteLink; ?>/admin/users"> <button class="menu-button"><i class="fas fa-users"></i> User Management</button></a> 
   <a href="<?php echo $siteLink; ?>/admin/admins">
    <button class="menu-button"><i class="fas fa-users"></i> Admins</button>
</a>
   <a href="<?php echo $siteLink; ?>/admin/withdrawals"> <button class="menu-button"><i class="fas fa-money-bill"></i> Withdrawal Requests</button></a> 
    <a href="<?php echo $siteLink; ?>/admin/tickets"><button class="menu-button"><i class="fas fa-ticket-alt"></i> Support Tickets</button></a> 
    <a href="<?php echo $siteLink; ?>/admin/settings"><button class="menu-button"><i class="fas fa-cogs"></i> Settings</button></a> 
</div>

<script>
    function hide() {
        const menu = document.getElementById("admin-menu");
        menu.style.display = "none";
    }
     function show() {
        const menu = document.getElementById("admin-menu");
        menu.style.display = "block";
    }
       
        function hideAlert() {
    var successAlert = document.getElementById("alert");
    if (successAlert) {
        successAlert.style.display = "none";
    }
}

</script>
</body>
</html>

