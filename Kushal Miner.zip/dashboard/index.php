<?php
include_once "../includes/settings.php";
include_once "../includes/header.php";
include_once "../config/dbconfig.php";
$sql = "SELECT * FROM plans ORDER BY id ASC";
$result = $conn->query($sql);

$usersql = "SELECT balance, cashouts, earnings, email, user_id, joined_at FROM users WHERE username = '$username'";

// Execute the query
$userresult = $conn->query($usersql);

if ($userresult) {
    // Fetch the data as an associative array
    $user = $userresult->fetch_assoc();
    $user_id = $user["user_id"];
    $earnings = $user["earnings"];
    $email = $user["email"];
} else {
    echo "Error: " . $usersql . "<br>" . $conn->error;
}

$active = "SELECT * FROM user_plans WHERE user_id = '$user_id' AND status = 'active'";
$activeresult = $conn->query($active);
$activeres = $conn->query($active);

   $amount_locked = 0.000000;




if ($activeres->num_rows > 0) {
    // Loop through each expired plan and update the status
    while ($row_active_plan = $activeres->fetch_assoc()) {
        $active_plan_id = $row_active_plan['plan_id'];

        // Step 2: Update the status for the expired plan to 'expired'

        // Step 3: Get amount_daily from plans where id = plan_id
        $sql_select_amount = "SELECT amount_daily FROM plans WHERE id = $active_plan_id";
        $result_amount = $conn->query($sql_select_amount);

        if ($result_amount->num_rows > 0) {
            $row_amount = $result_amount->fetch_assoc();
            $amount_locked += $row_amount['amount_daily'];


        }
       
    }
} else {
}


?>

<?php
$tamd = "0.00000000";
$amount_daily= 0.00000000;
$cur_date = gmdate('Y-m-d H:i:s');
// Step 1: Select plans that have end_date behind the current date
$sql_select_expired_plans = "SELECT plan_id, start_date, end_date FROM user_plans WHERE user_id = $user_id AND end_date < '$cur_date' AND status = 'active'";
$result_expired_plans = $conn->query($sql_select_expired_plans);

if ($result_expired_plans->num_rows > 0) {
    // Loop through each expired plan and update the status
    while ($row_expired_plan = $result_expired_plans->fetch_assoc()) {
        $expired_plan_id = $row_expired_plan['plan_id'];

        // Step 2: Update the status for the expired plan to 'expired'
        $sql_update_expired_status = "UPDATE user_plans SET status = 'expired' WHERE user_id = $user_id AND plan_id = $expired_plan_id";
        $update_result = $conn->query($sql_update_expired_status);

        if (!$update_result) {
            echo "Error updating status: " . $conn->error;
        }

        // Step 3: Get amount_daily from plans where id = plan_id
        $sql_select_amount_daily = "SELECT amount_daily, duration FROM plans WHERE id = $expired_plan_id";
        $result_amount_daily = $conn->query($sql_select_amount_daily);

        if ($result_amount_daily->num_rows > 0) {
            $row_amount_daily = $result_amount_daily->fetch_assoc();
            $amount_daily = $row_amount_daily['amount_daily'] * $row_amount_daily['duration'];

            $tamd += $amount_daily;
       

        }
        // You can add additional actions or notifications here if needed
    }
  $add = $user["balance"] + $tamd;
         
         $deduct = $user["earnings"] - $tamd;
       $deduct = $user["earnings"] - $tamd;

// Check if $deduct is less than 0, and set it to 0.000000 if true
if ($deduct < 0) {
    $deduct = 0.000000;
}

    // Step 4: Update earnings in the user's table
    $sql_update_earnings = "UPDATE users SET balance = $add WHERE user_id = $user_id";
    $update_earnings_result = $conn->query($sql_update_earnings);

    if (!$update_earnings_result) {
        echo "Error updating earnings: " . $conn->error;
    }
    $sql_minus_earnings = "UPDATE users SET earnings = $deduct WHERE user_id = $user_id";
    $update_minus_result = $conn->query($sql_minus_earnings);
     if (!$update_minus_result) {
        echo "Error updating earnings: " . $conn->error;
    }
echo '<script type="text/javascript">';
echo 'location.reload();';
echo '</script>';
} else {
    // Handle the case when there are no expired plans
}

?>
















<?php
$total_aps = 0.000;
$tamount_per_seconds = 0.0000;
$taps = 0.0000;
$tus = 0.000;

// Fetch user plans with status 'active'
$aquery = "SELECT plan_id, start_date, end_date FROM user_plans WHERE user_id = $user_id AND status = 'active'";
$aresult = mysqli_query($conn, $aquery);

if ($aresult) {
    if (mysqli_num_rows($aresult) > 0) {
        while ($row = mysqli_fetch_assoc($aresult)) {
            // Extract data from the row
            $plan_id = $row['plan_id'];
            $start_date = $row['start_date'];
            $end_date = $row['end_date'];

            // Get amount_daily from plans table using plan_id
            $planQuery = "SELECT amount_daily, duration FROM plans WHERE id = $plan_id";
            $planResult = mysqli_query($conn, $planQuery);

            if ($planResult) {
                $planRow = mysqli_fetch_assoc($planResult);
                $amount_daily = $planRow['amount_daily'] * $planRow['duration'];
                $dur = $planRow['duration'];
                $currentTimeGMT = gmdate('Y-m-d H:i:s');

                // Calculate time used in seconds
                $time_used_seconds = (86400 * $dur) - (strtotime($end_date) - strtotime($currentTimeGMT));
                $tus += $time_used_seconds;

                // Calculate amount_per_seconds
                $amount_per_seconds = $amount_daily / (24 * 60 * 60 * $dur) ; // Amount per second
                $tamount_per_seconds = $amount_per_seconds;

                // Calculate total amount earned
                $total_aps += ($tamount_per_seconds * $time_used_seconds);
                $taps += $total_aps;
                // Reset variables for the next iteration
                $time_used_seconds = 0;
            } else {
                // Handle error if needed
                echo "Error fetching plan details: " . mysqli_error($conn);
            }
        }

              
        // Update earnings in the users table after processing all rows
        $updateQuery = "UPDATE users SET earnings = $total_aps WHERE user_id = $user_id";
        $updateResult = mysqli_query($conn, $updateQuery);

        if ($updateResult) {
          
        } else {
            echo "Error updating earnings: " . mysqli_error($conn);
        }
    } else {
      
    }
} else {
    // Handle error if needed
    echo "Error executing query: " . mysqli_error($conn);
}


?>









<?php
$bale = "SELECT balance, earnings FROM users WHERE username = '$username'";

// Execute the query
$balresult = $conn->query($bale);

if ($balresult) {
    // Fetch the data as an associative array
    $bale = $balresult->fetch_assoc();
    $bal = $bale["balance"] + $bale["earnings"];
} else {
    echo "Error: " . $usersql . "<br>" . $conn->error;
}
?>
<body>
 <h2 class="center"><i class="fas fa-chart-line"></i> Account Dashboard</h2>
     <?php
if(isset($_GET["type"])) {
if ($_GET["type"] == "buysuccess") {
    echo '<div id="alert" class="success-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>Payment Successfull Your Plan Will be activated in one minute</p>
    </div>
    <script>window.location.href ="../dashboard";</script>';
} else if ($_GET["type"] == "error" && isset($_GET["message"])) {
    echo '<div id="alert" class="error-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
}
}
?>
 <div class="section-container">

<div class="section-card">
    <div class="balance">
        <p class="bold topper"><i class="fas fa-wallet"></i> Balance</p>
        <hr>
   <p class="bold"> <i class="fas fa-check-circle green-bg"></i> <span class="" id="bal"> <?php echo $bal ?> </span> <?php echo $curr_symbol; ?></p>
       
    </div>
    
    <button onclick="location.href='../withdrawal'" class="withdrawal-button"><i class="fas fa-money-bill"></i> Withdrawal</button>
</div>
<div class="section-card">
    <div class="balance">
        <div class="topper">
        <p class="bold"><i class="fas fa-user"></i> User</p>
        </div>
        <hr>
        <p class="username bold"><span id="username"><?php echo $username; ?></span> </p>
    <p class="username bold"><span id="email"><?php echo $email; ?></span> </p>
    <p style="font-size: 20px;" class="center">User Id - <?php echo $user_id; ?></p> 
    </div>
    <button onclick="location.href='../account'" class="acct-btn"><i class="fas fa-user"></i>
 Account</button>
</div>
</div>
<div class="active-plans-section">
    <h2 class="black center">Your Active Plans</h2>
    <table class="active-plans-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Speed</th>
                <th>Earning Rate</th>
                <th>Start</th>
                <th>Time Left</th>
            </tr>
        </thead>
        <tbody>
  <?php
  $trate = 0.00000000;
  $tdaily = 0.00000000;
  $speed = 0.00000000;
if ($activeresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $activeresult->fetch_assoc()) {
        // Fetch additional information from the plans table based on plan_id
        $plan_id = $row['plan_id'];
        $planInfoSql = "SELECT name, amount_daily, duration, Speed FROM plans WHERE id = $plan_id";
        $planInfoResult = $conn->query($planInfoSql);

        if ($planInfoResult->num_rows > 0) {
            $planInfo = $planInfoResult->fetch_assoc();

            echo '<tr>';
            echo '<td>' . $planInfo['name'] . '</td>';
            
            // Calculate the rate (amount per minute)
            $amount_daily = $planInfo['amount_daily'];
            $rate = number_format(($amount_daily *  $planInfo['duration'])/ (24 * 60), 10) ; 
            $trate += $rate;
            $tdaily += ($amount_daily *  $planInfo['duration']);
            
            echo '<td> ' . $planInfo['Speed'] . ' H/s</td>';
            $speed += $planInfo['Speed'];
            echo '<td> ' . $rate .' ' . $curr_symbol.'</td>';
            // Calculate the time left
            $curr_date = gmdate('Y-m-d H:i:s');
            $startTimestamp = new DateTime($curr_date);
            $endTimestamp = new DateTime($row['end_date']);
            $timeDifference = $startTimestamp->diff($endTimestamp);
           $totalSeconds = $timeDifference->s + $timeDifference->i * 60 + $timeDifference->h * 3600 + $timeDifference->days * 86400;

// Calculate hours, minutes, and remaining seconds
$totalHours = floor($totalSeconds / 3600);
$totalMinutes = floor(($totalSeconds % 3600) / 60);
$remainingSeconds = $totalSeconds % 60;
$reslt = sprintf("%dhr %dmin %dsec", $totalHours, $totalMinutes, $remainingSeconds);
            echo '<td>' . $row['start_date'] . '</td>';
            echo "<td> $reslt ";
            
            echo '</tr>';
           
        }
    }
     echo'<tr>
                <td class="bold">Totals</td>
                <td>'.$speed.' H/S</td>
                <td class="center" colspan="5"> ' .$trate .' '. $curr_symbol .'/ Min & '.$tdaily .' '.$curr_symbol.'/Day </td>
            </tr>';
} else {
    // If there are no active plans, display a message
    echo '<tr><td colspan="6">No Active Plans</td></tr>';
}

// Close the database connection
$conn->close();
?>
        </tbody>
    </table>
</div>
   
<div class="mining-plans-section">
    <div class="mining-plans-header uline">Buy A Mining Plan</div>
    <div class="mining-plans-description">Update your <?php echo $siteName;?> Mining Power with these plans and earn more <?php echo $currency;?> (<?php echo $curr_symbol;?>)</div>
    
    <div class="plan-container">
          <?php
          
        // Loop through the result set and display each row in the table
        while ($row = $result->fetch_assoc()) {
            echo '
            <div class="plan-card">
            <div class="investment-icon">
    <i class="fas fa-chart-line"></i>
  </div>
            <div class="plan-name">' . $row['name'] . '</div>
            <div class="plan-amount">' . $row['price'] .' '. $currency .' </div>
             <div>
            <ul class="plan-details">
            <li>' . $row['amount_daily'] . ' ' .$currency .'/ per day</li>
            ';
            $per = (($row['amount_daily'])/$row['price']) *100;
            $total_profits = $row['amount_daily'] * $row['duration'];
            echo'
            <li>'.$per.'% for ' . $row['duration'] .' days</li>
            <li>Total Profit '.$total_profits.' '.$currency.'</li>
            <li>Affiliate bonus 10%</li>
            </ul>
            </div>
            <a href="../purchase?id='. $row["id"] .'"><button class="buy-button"><i class="fas fa-shopping-cart"></i>
Buy</button></a>
            </div>';
        }
        ?>
    </div>
</div>


<?php
include_once "../includes/footer.php";
?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
$(document).ready(function() {
		let speed = (parseFloat(<?php echo $tamount_per_seconds;?>)).toFixed(5);
		setInterval(function() {
			let oldvalue =  parseFloat($('#bal').html()).toFixed(8);
			let result = parseFloat(parseFloat(oldvalue) + parseFloat(speed)).toFixed(8);
			$("#bal").html(result);
		}, 1000);
	});

document.addEventListener('DOMContentLoaded', function() {
           // Get the username element
var usernameElement = document.getElementById('username');

// Store the full username
var originalUsername = usernameElement.innerText;

// Show only the last 6 characters initially
usernameElement.innerText = 'XXXXXX' + originalUsername.substring(originalUsername.length - 6);

            // Add a click event listener to show the full username
            usernameElement.addEventListener('click', function() {
                usernameElement.innerText = originalUsername;
            });
        });
</script>

</body>
</html>

