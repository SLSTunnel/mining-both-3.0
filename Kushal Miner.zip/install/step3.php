<!DOCTYPE html>
<html>
<head>
<title>Kushal Installer</title>
    <link rel="stylesheet" type="text/css" href="css/step4.css">
</head>
<body>
    <div class="container">
        <h1>Admin Login</h1>
        <form action="saveadmin.php" method="post">
            <div class="form-group">
                <label for="adminUsername">Admin Username:</label>
                <input type="text" id="adminUsername" name="adminUsername" required>
            </div>
            <div class="form-group">
                <label for="adminEmail">Admin Email:</label>
                <input type="email" id="adminEmail" name="adminEmail" required>
            </div>
            <div class="form-group">
                <label for="adminPassword">Admin Password:</label>
                <input type="password" id="adminPassword" name="adminPassword" required>
            </div>
            <button type="submit" class="login-button">Continue</button>
        </form>
    </div>
</body>
</html>
