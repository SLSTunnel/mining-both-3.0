<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $siteName = $_POST["site_name"];
    $currency = $_POST["currency"];
    $curr_symbol = $_POST["curr_symbol"];
    $keywords = $_POST["site_keywords"];
    $description = $_POST["site_description"];
    $apiKey = $_POST["revelon_apiKey"];
    $revelon_currency = $_POST["revelon_currency"];
    $pay_coin = $_POST["revelon_paycoin"];
    $stmpHost = $_POST["stmp_host"];
    $stmpUsername = $_POST["stmp_username"];
    $stmpPassword = $_POST["stmp_password"];
    $stmpSecure = $_POST["stmp_secure"];
    $stmpPort = $_POST["stmp_port"];
    $sendFrom = $_POST["sender_email"];
    $min_with = $_POST["min_with"];
    $max_with = $_POST["max_with"];
    $min_wallet = $_POST["min_wallet"];
    $max_wallet = $_POST["max_wallet"];
    $ref_bonus = $_POST["ref_bonus"];
    $blockchain_url = $_POST["blockchain_url"];
    
    // Create the settings.php content
    $settingsContent = "<?php\n";
    $settingsContent .= "\$siteName = \"$siteName\";\n";
    $settingsContent .= "\$currency = \"$currency\";\n";
    $settingsContent .= "\$curr_symbol = \"$curr_symbol\";\n";
    $settingsContent .= "\$keywords = \"$keywords\";\n";
    $settingsContent .= "\$description = \"$description\";\n";
    $settingsContent .= "\$apiKey = \"$apiKey\";\n";
    $settingsContent .= "\$revelon_currency = \"$revelon_currency\";\n";
    $settingsContent .= "\$pay_coin = \"$pay_coin\";\n";
    $settingsContent .= "\$stmpHost = \"$stmpHost\";\n";
    $settingsContent .= "\$stmpUsername = \"$stmpUsername\";\n";
    $settingsContent .= "\$stmpPassword = \"$stmpPassword\";\n";
    $settingsContent .= "\$stmpSecure = \"$stmpSecure\";\n";
    $settingsContent .= "\$stmpPort = \"$stmpPort\";\n";
    $settingsContent .= "\$sendFrom = \"$sendFrom\";\n";
    $settingsContent .= "\$min_with = $min_with;\n";
    $settingsContent .= "\$max_with = $max_with;\n";
    $settingsContent .= "\$min_wallet = $min_wallet;\n";
    $settingsContent .= "\$max_wallet = $max_wallet;\n";
    $settingsContent .= "\$ref_bonus = \"$ref_bonus\";\n";
    $settingsContent .= "\$blockchain_url = \"$blockchain_url\";\n";
    $settingsContent .= "?>";


    // Write the settings to settings.php
    file_put_contents('../includes/settings.php', $settingsContent);

    // Redirect to step4.php
    header("Location: step3.php");
    exit();
}
?>
