<!DOCTYPE html>
<html>
<head>
        
<title>Kushal Installer</title>
    <link rel="stylesheet" type="text/css" href="css/step1.css">
</head>
<body>
    <div class="container">
        <h1>Database Setup</h1>
        <div class="instructions">
            <small>
                <ol>
                    <li>Access the cPanel of your hosting</li>
                    <li>Click on "MySQL® Databases"</li>
                    <li>On "Create New Database," fill the field with a name for your database and click on the "Create Database" button. Copy and paste the database name on the "Database Name" field below</li>
                    <li>On "Add New User," fill the field with a username for your database. Click on the "Password Generator" button, copy the generated password and paste it into the "Database Password" field below. Check the "I have copied this password in a safe place" field and click on the "Use Password" button. Click on "Create User" button, copy and paste the username into the "Database Username" field below.</li>
                    <li>On "Add User To Database," choose the username and database created before, click on the "Add" button, check the "ALL PRIVILEGES" box, and click on the "Make Changes" button.</li>
                </ol>
            </small>
        </div>
        <div class="video-tutorial">
            <a href="https://www.youtube.com/your-tutorial-link" target="_blank">Video Tutorial on YouTube</a>
        </div>
        <form action="dbconfig.php" method="post">
            <div class="form-group">
                <label for="dbHost">Database Host:</label>
                <input type="text" id="dbHost" name="dbHost" required>
            </div>
            <div class="form-group">
                <label for="dbPort">Database Port:</label>
                <input type="text" id="dbPort" name="dbPort" required>
            </div>
            <div class="form-group">
                <label for="dbName">Database Name:</label>
                <input type="text" id="dbName" name="dbName" required>
            </div>
            <div class="form-group">
                <label for="dbUsername">Database Username:</label>
                <input type="text" id="dbUsername" name="dbUsername" required>
            </div>
            <div class="form-group">
                <label for="dbPassword">Database Password:</label>
                <input type="password" id="dbPassword" name="dbPassword" required>
            </div>
            <button type="submit" class="continue-button">Continue</button>
        </form>
    </div>
</body>
</html>
