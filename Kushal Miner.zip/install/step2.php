<!DOCTYPE html>
<html>
<head>
<title>Kushal Installer</title>

    <link rel="stylesheet" type="text/css" href="css/step2.css">
    <link rel="stylesheet" type="text/css" href="../admin/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Site Settings</h1>
        <form action="save_settings.php" method="post">
           <div class="settings-section">
        <div class="section-title">Main Settings</div>
        <label class="settings-label">Site Name</label>
        <input type="text" class="settings-input" name="site_name" placeholder="Site Name">
        <label class="settings-label">Site Keywords</label>
        <input type="text" class="settings-input" name="site_keywords" placeholder="Site Keywords">
        <label class="settings-label">Site Description</label>
        <textarea type="text" class="settings-input" name="site_description" placeholder="Site Description"></textarea>
    </div>

    <div class="settings-section">
        <div class="section-title">Limit Settings</div>
        <label class="settings-label">Min Withdrawal</label>
        <input type="number" class="settings-input" name="min_with" placeholder="Min Withdrawal">
        <label class="settings-label">Max Withdrawal</label>
        <input type="text" class="settings-input" name="max_with" placeholder="Max Withdrawal">
        <label class="settings-label">Affiliate Commission (%)</label>
        <input type="text" class="settings-input" name="ref_bonus" placeholder="Affiliate Commission (%)">
    </div>

    <div class="settings-section">
        <div class="section-title">Currency Settings</div>
        <label class="settings-label">Currency Name</label>
        <input type="text" class="settings-input" name="currency" placeholder="Currency Name">
        <label class="settings-label">Currency Symbol</label>
        <input type="text" class="settings-input" name="curr_symbol" placeholder="Currency Symbol">
        <label class="settings-label">Wallet Address Min Chars</label>
        <input type="text" class="settings-input" name="min_wallet" placeholder="Wallet Address Min Chars">
        <label class="settings-label">Wallet Address Max Chars</label>
        <input type="text" class="settings-input" name="max_wallet"  placeholder="Wallet Address Max Chars">
        <label class="settings-label">Blockchain Tracking Url</label>
        <input type="text" class="settings-input" name="blockchain_url" placeholder="Blockchain Tracking Url">
    </div>

    <div class="settings-section">
       <a href="revelon.net"> <div class="section-title">Revelon Settings</div></a>
        <label class="settings-label">Revelon Currency</label>
        <input type="text" class="settings-input" name="revelon_currency" placeholder="Revelon Currency">
        <label class="settings-label">Payment Coin <p class="desc">(This is the coin which users will pay with)</p></label>
        
        <input type="text" class="settings-input" name="revelon_paycoin" placeholder="Payment Coin">
        <label class="settings-label">Revelon  Api Key</label><p class="desc">(You Can Get Your<a href="https://revelon.net"> Revelon</a> ApiKey <a href="https://revelon.net/api">Here)</a></p>
        <input type="text" class="settings-input" name="revelon_apiKey" placeholder="Revelon API Key">
    </div>

    <div class="settings-section">
        <div class="section-title">Email Settings</div>
        <label class="settings-label">SMTP Host</label>
        <input type="text" class="settings-input" name="stmp_host" placeholder="SMTP Host">
        <label class="settings-label">SMTP Port</label>
        <input type="text" class="settings-input" name="stmp_port" placeholder="SMTP Port">
        <label class="settings-label">SMTP Secure  <p class="desc">(SSL, TLS, STARTlS)</p></label>
        <input type="text" class="settings-input" name="stmp_secure" placeholder="SMTP Secure">
        <label class="settings-label">SMTP Username</label>
        <input type="text" class="settings-input" name="stmp_username" placeholder="SMTP Username">
        <label class="settings-label">Sender Email</label>
        <input type="text" class="settings-input" name="sender_email" placeholder="SMTP Sender Email">
        <label class="settings-label">SMTP Password</label>
        <input type="password" class="settings-input" name="stmp_password" placeholder="SMTP Password">
    </div>
            <button type="submit" class="submit-button">Submit</button>
        </form>
    </div>
</body>
</html>
