<!DOCTYPE html>
<html>
<head>
<title>Kushal Installer</title>
    <link rel="stylesheet" type="text/css" href="css/step5.css">
</head>
<body>
    <div class="container">
        <h1>Installation Finished</h1>
        <p>Click the button below to finish the installation, remove installation URLs, and go to your site. Maintaining installation URLs may cause a reinstallation of the database and consequently data loss.</p>
        <button onclick="location.href='../config/installdn.php'" class="finish-button">Remove Installation Routes and Go to Admin</button>
    </div>
</body>
</html>
