<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost = $_POST['dbHost'];
    $dbPort = $_POST['dbPort'];
    $dbName = $_POST['dbName'];
    $dbUsername = $_POST['dbUsername'];
    $dbPassword = $_POST['dbPassword'];

    // Create a database connection
    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPort);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Database connection is successful
    // Save the connection details to dbconfig.php
    $dbConfig = "<?php\n";
    $dbConfig .= "\$dbHost = \"$dbHost\";\n";
    $dbConfig .= "\$dbPort = \"$dbPort\";\n";
    $dbConfig .= "\$dbName = \"$dbName\";\n";
    $dbConfig .= "\$dbUsername = \"$dbUsername\";\n";
    $dbConfig .= "\$dbPassword = \"$dbPassword\";\n";
    $dbConfig .= "\$conn = new mysqli(\$dbHost, \$dbUsername, \$dbPassword, \$dbName, \$dbPort);\n";
    $dbConfig .= "if (\$conn->connect_error) {\n";
    $dbConfig .= "    die(\"Connection failed: \" . \$conn->connect_error);\n";
    $dbConfig .= "}\n";
    $dbConfig .= "?>";

    // Write the connection details to dbconfig.php
    file_put_contents('../config/dbconfig.php', $dbConfig);

    // Upload the db.sql file to the database
    $sqlFile = 'db.sql';
    $sql = file_get_contents($sqlFile);

    if ($conn->multi_query($sql)) {
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->next_result());
    }

    // Redirect to step2.php
    header("Location: step2.php");
    exit();
}
?>
