<?php
// Include the database configuration
include('../config/dbconfig.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the admin username and password from the form
    $adminUsername = $_POST['adminUsername'];
    $adminPassword = $_POST['adminPassword'];
    $adminEmail = $_POST['adminEmail'];

    // Encrypt the admin password
    $hashedPassword = password_hash($adminPassword, PASSWORD_BCRYPT);

    // Connect to the database using the configuration from dbconfig.php

    // Insert the admin credentials into the admin table
    $sql = "INSERT INTO admins (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $adminUsername, $adminEmail, $hashedPassword);

    if ($stmt->execute()) {
        // Redirect to step5.php on success
        header("Location: step4.php");
        exit();
    } else {
        // Handle the error or show a failure message
        echo "Admin registration failed.";
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>
