<!DOCTYPE html>
<html>
<head>
<title>Kushal Installer</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Kushal Installer</h1>
        <p>To Add A Logo Pls Upload Your Logo To assets/images (Upload logo.png and favicon.png)</p>
        <div class="requirements">
            <h2>System Requirements</h2>
            <ul>
                <li>PHP Version 7 and above
                    <?php echo (version_compare(phpversion(), '7.0.0') >= 0) ? '<span class="green-mark">✔</span>' : '<span class="red-x">✘</span>'; ?>
                </li>
                <li>File_get_contents
                    <?php echo (function_exists('file_get_contents')) ? '<span class="green-mark">✔</span>' : '<span class="red-x">✘</span>'; ?>
                </li>
                <li>MySQLi or PDO
                    <?php echo (extension_loaded('mysqli') || extension_loaded('pdo')) ? '<span class="green-mark">✔</span>' : '<span class="red-x">✘</span>'; ?>
                </li>
                <li>db.sql file in the root directory
                    <?php echo (file_exists('db.sql')) ? '<span class="green-mark">✔</span>' : '<span class="red-x">✘</span>'; ?>
                </li>
            </ul>
        </div>
        <?php
        if (version_compare(phpversion(), '7.0.0') >= 0 &&
            function_exists('file_get_contents') &&
            (extension_loaded('mysqli') || extension_loaded('pdo')) &&
            file_exists('db.sql')) {
            echo '<a href="step1.php" class="continue-button">Continue</a>';
        } else {
            echo '<a href="index.php" class="recheck-button">Recheck</a>';
        }
        ?>
    </div>
</body>
</html>
