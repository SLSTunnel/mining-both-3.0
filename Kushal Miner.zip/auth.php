<?php
// Include the database configuration file
include 'config/dbconfig.php';
include 'includes/settings.php';
// Start the session
session_start();

// Initialize the response array
$response = array();

// Check if username, upline, and password are provided through POST
if (isset($_POST['username']) && isset($_POST['upline']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $upline = $_POST['upline'];
    $password = $_POST['password'];

    // Check if the length of $username is within the allowed range
    $usernameLength = strlen($username);
    if ($usernameLength < $min_wallet || $usernameLength > $max_wallet) {
        $response['status'] = 'error';
        $response['error'] = 'Invalid '.$curr_symbol.' address';
    } else {
        // Check if the username exists in the database
        $checkUserQuery = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($checkUserQuery);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User exists, verify password
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Password is correct, set session user
                $_SESSION['user'] = $username;

                // Set success response
                $response['status'] = 'success';
            } else {
                // Incorrect password
                $response['status'] = 'error';
                $response['error'] = 'Incorrect password';
            }
        } else {
            // User does not exist, create a new account
            $user_id = rand(10000, 99999);
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $createdAt = gmdate('Y-m-d H:i:s');

            $insertUserQuery = "INSERT INTO users (user_id, username, password, upline, joined_at) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertUserQuery);
            $stmt->bind_param("sssss", $user_id, $username, $hashedPassword, $upline, $createdAt);
            $stmt->execute();

            // Set session user
            $_SESSION['user'] = $username;

            // Set success response
            $response['status'] = 'success';
        }
    }
} else {
    // Missing username, upline, or password
    $response['status'] = 'error';
    $response['error'] = 'Missing username, upline, or password';
}

// Close the database connection

$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit();
?>
