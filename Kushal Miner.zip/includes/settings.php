<?php
$siteName = "Your_Site_Name";
$currency = "Your_Currency";
$curr_symbol = "Your_Currency_Symbol";
$keywords = "Your_Keywords";
$description = "Your_Site_Description";
$apiKey = "Your_API_Key";
$revelon_currency = "Your_Revelon_Currency";
$pay_coin = "Your_Payment_Coin";
$stmpHost = "Your_SMTP_Host";
$stmpUsername = "Your_SMTP_Username";
$stmpPassword = "Your_SMTP_Password";
$stmpSecure = "Your_SMTP_Secure";
$stmpPort = "Your_SMTP_Port";
$sendFrom = "Your_Sender_Email";
$min_with = "Your_Min_Withdraw";
$max_with = "Your_Max_Withdraw";
$min_wallet = "Your_Min_Wallet_Characters";;
$max_wallet = "Your_Max_Wallet_Characters";
$ref_bonus = "Your_Affiliate_Commission";
$blockchain_url = "Your_Blockchain_URL";
?>
