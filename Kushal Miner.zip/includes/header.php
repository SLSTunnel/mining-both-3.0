<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: ../');
    exit(); // Ensure that no further code is executed after the redirect
} 
 include '../config/dbconfig.php';
    $username = $_SESSION['user'];
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$siteLink = $protocol . "://" . $_SERVER['HTTP_HOST'] ;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $siteName; ?></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?php echo $description;?>">
  <meta name="keywords" content="<?php echo $keywords;?>">
  <meta name="author" content="Kushal Techs"/>    
  <link rel="icon" href="<?php echo $siteLink;?>/assets/images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link rel="stylesheet" href="<?php echo $siteLink?>/assets/css/main.css">
</head>
<body>

  <header>
    <div class="site-name"><?php echo $siteName; ?></div>
    <nav>
      <a href="<?php echo $siteLink; ?>/dashboard">Dashboard</a>
          <a href="<?php echo $siteLink; ?>/withdrawal">Withdrawal</a>
          <a href="<?php echo $siteLink; ?>/account">Account</a>
          <a href="<?php echo $siteLink; ?>/payouts">Payouts</a>
          <a href="<?php echo $siteLink; ?>/logout">Logout</a>

    </nav>
   <div id="menu-toggle"  onclick="toggleMenu()">&#9776;</div>
  </header>

  <script src="<?php echo $siteLink?>/assets/js/script.js">  </script>

