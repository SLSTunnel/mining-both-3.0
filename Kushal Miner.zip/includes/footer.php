<div class="footer">
    <div class="footer-content">
        <div class="site-info">
            <h3><?php echo $siteName; ?></h3>
            <p><?php echo $description; ?></p>
        </div>
        <div class="quick-links">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="<?php echo $siteLink; ?>/">Home</a></li>
                <li><a href="<?php echo $siteLink; ?>/payouts">Payouts</a></li>
                <li><a href="<?php echo $siteLink; ?>/faq">Faq</a></li>
            </ul>
        </div>
        <div class="contact-us">
            <h4>Contact Us</h4>
            <ul>
                <li><span class="fa fa-envelope"></span><a href="<?php echo $siteLink; ?>/support">Contact Form</a></li>
		  	<li><span class="fa fa-headphones"></span> <?php echo $sendFrom;?></li>
            </ul>
        </div>
    </div>
    <hr>
    <p class="copyright">&copy; <?php echo $siteName; ?> <?php echo date("Y");?></p>
</div>