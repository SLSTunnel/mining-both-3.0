<?php
include_once "../includes/settings.php";
include_once "../includes/header.php";

$usersql = "SELECT email, user_id FROM users WHERE username = '$username'";

// Execute the query
$userresult = $conn->query($usersql);

if ($userresult) {
    // Fetch the data as an associative array
    $user = $userresult->fetch_assoc();
    $user_id = $user["user_id"];
} else {
    echo "Error: " . $usersql . "<br>" . $conn->error;
}
$withsql = "SELECT * FROM withdrawals WHERE username = '$username' ORDER BY created_at DESC"; 
$withresult = $conn->query($withsql);


$depsql = "SELECT * FROM user_deposits WHERE user_id = '$user_id' ORDER BY created_at DESC";
$depresult = $conn->query($depsql);

$refsql = "SELECT * FROM users WHERE upline = '$user_id' ORDER BY joined_at DESC";
$refresult = $conn->query($refsql);


?>
<body>

<div class="account-settings-form">
<?php
if(isset($_GET["type"])) {
if ($_GET["type"] == "success" && $_GET["message"]) {
    echo '<div id="alert" class="success-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
} else if ($_GET["type"] == "error" && $_GET["message"]) {
    echo '<div id="alert" class="error-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
}
}
?>
   
    <div class="form-header">
        <h2>Update Account</h2>
    </div>
<form action="save.php" method="POST">
    <div class="account-form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"  value="<?php echo $user["email"]; ?>" placeholder="Enter your email">
    </div>

    <div class="account-form-group">
        <label for="new-password">New Password:</label>
        <input type="password" id="new-password" name="new-password" placeholder="Enter new password">
    </div>

    <div class="account-form-group">
        <label for="confirm-password">Confirm Password:</label>
        <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm new password">
    </div>

    <div class="account-form-group">
        <label for="current-password">Current Password:</label>
        <input type="password" id="current-password" name="current-password" placeholder="Enter current password">
    </div>

    <button type="submit" class="save-button">Save</button>
    </form>
</div>



<div class="referral-section">
    <h3>Your Referral Link</h3>
    <p class="referral-description">Earn <?php echo $ref_bonus; ?>% on every deposit</p>
    <input type="text" class="referral-input" value="<?php echo $siteLink; ?>?ref=<?php echo $user_id; ?>" readonly>
    <button class="copy-button" onclick="copyReferralLink()"><i class="fas fa-copy"></i> Copy</button>
</div>


<div class="history-container">
    
        <h2 class="underline">Account History</h2>
    <div class="history-menu">
        <button onclick="showTable('referrals')">Referrals</button>
        <button onclick="showTable('withdrawals')">Withdrawals</button>
        <button onclick="showTable('deposit-history')">Deposit History</button>
    </div>

    <div class="history-table referrals active">
        <h3>Referrals</h3>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>User ID</th>
                    <th>Date Joined</th>
                </tr>
            </thead>
            <tbody>
                                        
            <?php
       if ($refresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $refresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['username'] . '</td>';
        echo '<td>' . $row['user_id'] . '</td>';
        echo '<td>' . $row['joined_at'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No Referrals Yet</td></tr>';
}
        ?>
           
                <!-- Add referral data here -->
            </tbody>
        </table>
    </div>

    <div class="history-table withdrawals">
        <h3>Withdrawals</h3>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>txId</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                
         <?php
if ($withresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $withresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        
        // Check if $row['txHash'] is empty
        $txHashDisplay = !empty($row['txHash']) ? '<a href="' . $blockchain_url . '/' . $row['txHash'] . '">' . $row['txHash'] . '</a>' : 'none';
        echo '<td>' . $txHashDisplay . '</td>';
        
        echo '<td>' . $row['status'] . '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No withdrawals Yet</td></tr>';
}
?>


                <!-- Add withdrawal data here -->
            </tbody>
        </table>
    </div>

    <div class="history-table deposit-history">
        <h3>Deposits History</h3>
        <table>
            <thead>
                <tr><th>User Id</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                
                            
            <?php
       if ($depresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $depresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['user_id'] . '</td>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No Deposits Yet</td></tr>';
}
        ?>
                <!-- Add plan history data here -->
            </tbody>
        </table>
    </div>
</div>
</body>
<?php
include_once "../includes/footer.php";
?>