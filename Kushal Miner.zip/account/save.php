<?php
// Include your database configuration file
include('../config/dbconfig.php');
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $newPassword = $_POST["new-password"];
    $confirmPassword = $_POST["confirm-password"];
    $currentPassword = $_POST["current-password"];

    $username = $_SESSION['user'];

    // You should perform additional validation and sanitation as needed

    // Check if the email already exists
    $checkEmailStmt = $conn->prepare("SELECT username FROM users WHERE email = ? AND username != ?");
    $checkEmailStmt->bind_param("ss", $email, $username);
    $checkEmailStmt->execute();
    $checkEmailStmt->store_result();
    $emailExists = $checkEmailStmt->num_rows > 0;
    $checkEmailStmt->close();

    if ($emailExists) {
        header("Location: ./?type=error&message=Email already exists.");
        exit;
    }

    // Check if the current password is correct using password_verify
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($hashedPassword);
    $stmt->fetch();
    $stmt->close();

    if ($hashedPassword && password_verify($currentPassword, $hashedPassword)) {
        // Current password is correct

        // Check if the new password and confirmation are defined
        if (!empty($newPassword) && !empty($confirmPassword)) {
            // Check if the new password and confirmation match
            if ($newPassword === $confirmPassword) {
                // Hash the new password
                $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Update email and password in the users table
                $updateStmt = $conn->prepare("UPDATE users SET email = ?, password = ? WHERE username = ?");
                $updateStmt->bind_param("sss", $email, $hashedNewPassword, $username);
                $updateStmt->execute();
                $updateStmt->close();

                header("Location: ./?type=success&message=Changes saved successfully.");
                exit;
            } else {
                 header("Location: ./?type=error&message=New password and confirmation do not match");
                exit;
            }
        } else {
            // Update email only
            $updateEmailStmt = $conn->prepare("UPDATE users SET email = ? WHERE username = ?");
            $updateEmailStmt->bind_param("ss", $email, $username);
            $updateEmailStmt->execute();
            $updateEmailStmt->close();

            header("Location: ./?type=success&message=Email updated successfully.");
            exit;
        }
    } else {
        header("Location: ./?type=error&message=Wrong current password");
        exit;
    }

    // Close the database connection
    $conn->close();
} else {
    // If the form is not submitted, redirect or handle accordingly
    header("Location: index.php"); // Redirect to the appropriate page
    exit();
}
?>
