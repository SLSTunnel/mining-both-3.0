<?php
include_once "../includes/settings.php";
include_once "../includes/header.php";
include_once "../config/dbconfig.php";
?>
<?php

$usersql = "SELECT balance, cashouts, email, user_id, joined_at FROM users WHERE username = '$username'";

// Execute the query
$userresult = $conn->query($usersql);

if ($userresult) {
    // Fetch the data as an associative array
    $user = $userresult->fetch_assoc();
    $user_id = $user["user_id"];
} else {
    echo "Error: " . $usersql . "<br>" . $conn->error;
}


$cur_date = gmdate('Y-m-d H:i:s');


$tamd = 0.00000000;
// Step 1: Select plans that have end_date behind the current date
$sql_select_expired_plans = "SELECT plan_id, start_date, end_date FROM user_plans WHERE user_id = $user_id AND end_date < '$cur_date' AND status = 'active'";
$result_expired_plans = $conn->query($sql_select_expired_plans);

if ($result_expired_plans->num_rows > 0) {
    // Loop through each expired plan and update the status
    while ($row_expired_plan = $result_expired_plans->fetch_assoc()) {
        $expired_plan_id = $row_expired_plan['plan_id'];

        // Step 2: Update the status for the expired plan to 'expired'
        $sql_update_expired_status = "UPDATE user_plans SET status = 'expired' WHERE user_id = $user_id AND plan_id = $expired_plan_id";
        $update_result = $conn->query($sql_update_expired_status);

        if (!$update_result) {
            echo "Error updating status: " . $conn->error;
        }

        // Step 3: Get amount_daily from plans where id = plan_id
        $sql_select_amount_daily = "SELECT amount_daily FROM plans WHERE id = $expired_plan_id";
        $result_amount_daily = $conn->query($sql_select_amount_daily);

        if ($result_amount_daily->num_rows > 0) {
            $row_amount_daily = $result_amount_daily->fetch_assoc();
            $amount_daily = $row_amount_daily['amount_daily'];

            $tamd += $amount_daily;
         $add = $user["balance"] + $tamd;

        }
        // You can add additional actions or notifications here if needed
    }

    // Step 4: Update earnings in the user's table
    $sql_update_earnings = "UPDATE users SET balance = $add WHERE user_id = $user_id";
    $update_earnings_result = $conn->query($sql_update_earnings);

    if (!$update_earnings_result) {
        echo "Error updating earnings: " . $conn->error;
    }
echo '<script type="text/javascript">';
echo 'location.reload();';
echo '</script>';
} else {
    // Handle the case when there are no expired plans
}

?>
<?php
$bale = "SELECT balance FROM users WHERE username = '$username'";

// Execute the query
$balresult = $conn->query($bale);

if ($balresult) {
    // Fetch the data as an associative array
    $bale = $balresult->fetch_assoc();
    $bal = $bale["balance"];
} else {
    echo "Error: " . $usersql . "<br>" . $conn->error;
}
?>
  <title>Withdrawal Page</title>
</head>
<body>

  <div class="withdrawal-container">
      <?php
if(isset($_GET["type"])) {
if ($_GET["type"] == "success" && $_GET["message"]) {
    echo '<div id="alert" class="success-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
} else if ($_GET["type"] == "error" && $_GET["message"]) {
    echo '<div id="alert" class="error-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
}
}?>
    <h1 class="withhead">Request Withdrawal</h1>
    <p class="withdescription">Request withdrawal of your earnings to your <?php echo $curr_symbol;?> Wallet.</p>
    <p class="withdescription">Note You Can Only Withdrawal Your profit from a plan When Your Plan Is Done</p>

    <div class="balance-box">
      <p>Your Active Balance</p>
      <p class="balance-amount bold"><?php echo $bal; ?> <?php echo $curr_symbol; ?></p>
    </div>

    <div class="withdrawal-form">
        <form action="withdraw.php" method="POST">
      <label for="wallet-address">Enter Wallet Address</label>
      <input type="text" id="wallet-address" name="wallet-address" value="<?php echo $username; ?>" placeholder="Your <?php echo $curr_symbol;?> Wallet Address" readonly>

      <label for="amount">Enter Amount</label>
      <input type="text" id="amount" name="amount" placeholder="Amount in <?php echo $curr_symbol; ?>">
    </div>

    <button type="submit" class="withdraw-button"><i class="fas fa-check"></i> Confirm</button>
    </form>
  </div>
<?php
include_once "../includes/footer.php";
?>
</body>
</html>
