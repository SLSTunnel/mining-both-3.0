<?php
include_once "../config/dbconfig.php";
include_once "../includes/settings.php";
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $walletAddress = $_POST["wallet-address"];
    $amount = $_POST["amount"];
    $username = $_SESSION['user'];

    // You should perform additional validation and sanitation as needed

    // Get the user's balance from the database
    $balanceQuery = $conn->prepare("SELECT balance FROM users WHERE username = ?");
    $balanceQuery->bind_param("s", $username);
    $balanceQuery->execute();
    $balanceQuery->bind_result($balance);
    $balanceQuery->fetch();
    $balanceQuery->close();
    // Check if the amount is greater than the balance
    if ($amount > $balance) {
        header("Location: ./?type=error&message=Insufficient funds. Your balance is $balance $curr_symbol.");
                exit;
    } else {
        if ($amount < $min_with) {
             header("Location: ./?type=error&message=Min Withdrawal is $min_with $curr_symbol.");
             return
                exit;
        } else if ($amount > $max_with) {
              header("Location: ./?type=error&message=Max Withdrawal is $max_with $curr_symbol.");
             return
                exit;
        }
        // Deduct the amount from the balance
        $newbalance = $balance - $amount;

        // Update the user's balance in the database
        $updateBalanceQuery = $conn->prepare("UPDATE users SET balance = ? WHERE username = ?");
        $updateBalanceQuery->bind_param("ss", $newbalance, $username);
        $updateBalanceQuery->execute();
        $updateBalanceQuery->close();

        // Save withdrawal details
        $status = 'pending';
        $createdAt = gmdate('Y-m-d H:i:s');

        $withdrawalQuery = $conn->prepare("INSERT INTO withdrawals (username, amount, status, created_at) VALUES (?, ?, ?, ?)");
        $withdrawalQuery->bind_param("ssss", $username, $amount, $status, $createdAt);
        $withdrawalQuery->execute();
        $withdrawalQuery->close();

     header("Location: ./?type=success&message=Withdrawal Placed successfully.");
                exit;
    }
}
?>
