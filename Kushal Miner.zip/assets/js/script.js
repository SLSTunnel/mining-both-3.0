
    document.addEventListener("DOMContentLoaded", function () {
      const menuToggle = document.getElementById("menu-toggle");
      const nav = document.querySelector("nav");

      menuToggle.addEventListener("click", function () {
        nav.classList.toggle("show");
      });
    });
     function showTable(tableType) {
        // Hide all tables
        var tables = document.querySelectorAll('.history-table');
        tables.forEach(function(table) {
            table.classList.remove('active');
        });

        // Show the selected table
        document.querySelector('.' + tableType).classList.add('active');
    }
    
    function copyReferralLink() {
        var referralInput = document.querySelector('.referral-input');
        referralInput.select();
        document.execCommand('copy');
        alert('Referral link copied to clipboard!');
    }
        function toggleAnswer(faqId) {
        var faqAnswer = document.getElementById(faqId);
        var faqQuestion = faqAnswer.previousElementSibling;

        if (faqAnswer.classList.contains('active')) {
            faqAnswer.classList.remove('active');
            faqQuestion.innerHTML = '<i class="fas fa-plus toggle-icon"></i>' + faqQuestion.textContent.slice(2);
        } else {
            faqAnswer.classList.add('active');
            faqQuestion.innerHTML = '<i class="fas fa-minus toggle-icon"></i>' + faqQuestion.textContent.slice(2);
        }
    }
    
    
    
        function hideAlert() {
    var successAlert = document.getElementById("alert");
    if (successAlert) {
        successAlert.style.display = "none";
    }
}


function toggleMenu() {
    const nav = document.getElementById("navbar");

    if (nav.style.display === "none" || nav.style.display === "") {
        nav.style.display = "flex";
    } else {
        nav.style.display = "none";
    }
}