<?php
include_once "../includes/head.php"; 
include_once "../includes/settings.php"; 
?>

<title>Support</title>
<body>
    <div class="support-container">
        
        <form action="save.php" method="POST" class="support-form">
            <?php
if(isset($_GET["type"])) {
if ($_GET["type"] == "success" && $_GET["message"]) {
    echo '<div id="alert" class="success-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
} else if ($_GET["type"] == "error" && $_GET["message"]) {
    echo '<div id="alert" class="error-alert">
        <span class="close-alert" onclick="hideAlert()">X</span>
        <p>'.$_GET["message"].'</p>
    </div>';
}
}
?>
            <h2 class="center">Submit A Support Ticket</h2>
        <p class="center">(Our Team will get back to you via email)</p>
            <label class="support-label" for="name">Name</label>
            <input class="support-input" type="text" id="name" name="name" required>

            <label class="support-label" for="email">Email</label>
            <input class="support-input" type="email" id="email" name="email" required>
            
            <label class="support-label" for="subject">Subject</label>
            <input class="support-input" type="text" id="subject" name="subject" required>

            <label class="support-label" for="message">Message</label>
            <textarea class="support-textarea" id="message" name="message" rows="4" required></textarea>

            <button type="submit" class="support-button">Submit</button>
        </form>
    </div>
</body>
</html>

<?php
include_once "../includes/footer.php"; 
?>