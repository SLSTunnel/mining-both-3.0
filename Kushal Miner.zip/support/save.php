<?php
// Include your database configuration file
include('../config/dbconfig.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $currentTimeGMT = gmdate('Y-m-d H:i:s');
    $status = "pending";

    // You should perform additional validation and sanitation as needed

    // Insert data into the support_tickets table (replace with your actual table name)
    $insertQuery = "INSERT INTO support_tickets (name, email, message, subject, created_at, status) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("ssssss", $name, $email, $message, $subject, $currentTimeGMT, $status);

        // Execute the query
        $stmt->execute();

        // Close the statement
        $stmt->close();

        // Close the database connection
        $conn->close();

     
                header("Location: ./?type=success&message=Ticket Submitted Successfully, Our Team Will get back to you");
                exit;
    } else {
         header("Location: ./?type=error&message=Error Occured");
         exit;
    }
} else {
    // If the form is not submitted, handle accordingly
   header("Location: ./?type=error&message=Error Occured");
   exit;
}
?>
