<?php
include_once "includes/settings.php";
include_once "includes/head.php";

 include 'config/dbconfig.php';
$sql = "SELECT * FROM plans ORDER BY id ASC";
$result = $conn->query($sql);

$usersql = "SELECT COUNT(*) as totalusers FROM users";
$usersresult = $conn->query($usersql);

if ($usersresult === false) {
    die("Error executing the query: " . $conn->error);
}

// Fetch the result as an associative array
$users = $usersresult->fetch_assoc();

// Total number of users
$totalusers = $users['totalusers'];
$upline = isset($_GET["ref"]) ? $_GET["ref"] : "none";



 
// Initialize the total amount
$totalWithdrawals = 0;
$totalDeposits = 0;

// Query to get the total withdrawals where status is 'success'
$withquery = "SELECT SUM(amount) as total FROM withdrawals WHERE status = 'success'";
$withresult = mysqli_query($conn, $withquery);

if ($withresult) {
    // Fetch the result as an associative array
    $withs = mysqli_fetch_assoc($withresult);

    // Check if there is a result
    if ($withs['total'] !== null) {
        // Set the total withdrawals
        $totalWithdrawals = $withs['total'];
    }
} else {
    // Handle the query error if needed
    echo "Error: " . mysqli_error($conn);
}


$depoquery = "SELECT SUM(amount) as total FROM user_deposits WHERE status = 'success'";
$deporesult = mysqli_query($conn, $depoquery);

if ($deporesult) {
    // Fetch the result as an associative array
    $depos = mysqli_fetch_assoc($deporesult);

    // Check if there is a result
    if ($depos['total'] !== null) {
        // Set the total withdrawals
        $totalDeposits = $depos['total'];
    }
} else {
    // Handle the query error if needed
    echo "Error: " . mysqli_error($conn);
}




?>

    <title><?php echo $siteName; ?></title>
<style>
    .result {
        text-align: center;
        color: grey;
    }
</style>
<body>
    <section class="intro-section">
        <div id="get-started" class="intro-content">
            <h1 class="dh1">Welcome To <?php echo $siteName; ?> <i class="fas fa-mining"></i></h1>
            <p>We provide easy and free cloud mining services even for beginners. Join us in the journey of mining <?php echo $curr_symbol;?> and explore the benefits of our platform.</p>
            <a onclick="getStartedPopup()" class="get-started-btn">Get Started</a>
        </div>
       
    </section>
     <section class="steps-section">
        <h2 class="dh2">Start Earning Massively in 3 steps</h2>
        <div class="step">
            <div class="step-icon"><i class="fas fa-user-plus"></i></div>
            <h3 class="dh3">Register</h3>
            <p>Create a free account, with your wallet address and password.</p>
        </div>
        <div class="step">
            <div class="step-icon"><i class="fas fa-shopping-cart"></i></div>
            <h3>Buy Plans</h3>
            <p>Increase your mining power by purchasing one or more mining plans.</p>
        </div>
        <div class="step">
            <div class="step-icon"><i class="fas fa-coins"></i></div>
            <h3>Withdraw Earnings</h3>
            <p>Reaching the minimum withdrawal amount, request your payment.</p>
        </div>
    </section>
    
    <div class="mining-plans-section">
    <div class="mining-plans-header uline">Buy A Mining Plan</div>
    <div class="mining-plans-description">Update your Tron Digger with these plans and earn more Tron (TRX)</div>
    
    <div class="plan-container">
          <?php
          
        // Loop through the result set and display each row in the table
        while ($row = $result->fetch_assoc()) {
            echo '
            <div class="plan-card">
            <div class="investment-icon">
    <i class="fas fa-chart-line"></i>
  </div>
            <div class="plan-name">' . $row['name'] . '</div>
            <div class="plan-amount">' . $row['price'] .' '. $currency .' </div>
             <div>
            <ul class="plan-details">
            <li>' . $row['amount_daily'] . ' ' .$currency .'/ per day</li>
            ';
            $per = (($row['amount_daily'])/$row['price']) *100;
            $total_profits = $row['amount_daily'] * $row['duration'];
            echo'
            <li>'.$per.'% for ' . $row['duration'] .' days</li>
            <li>Total Profit '.$total_profits.' '.$currency.'</li>
            <li>Affiliate bonus 10%</li>
            </ul>
            </div>
            <a href="#get-started"><button class="buy-button"><i class="fas fa-shopping-cart"></i>
Buy</button></a>
            </div>';
        }
        ?>
    </div>
</div>
<section class="steps-section">
        <h2>Current Statistics</h2>
        <div class="step">
            <div class="step-icon"><i class="fas fa-users"></i></div>
            <h3><?php echo $totalusers;?></h3>
            <p>Users</p>
        </div>
        <div class="step">
            <div class="step-icon"><i class="fas fa-arrow-up"></i></div>
            <h3><?php echo $totalWithdrawals;?> <?php echo $currency;?></h3>
            <p>Withdrawals</p>
        </div>
        <div class="step">
            <div class="step-icon"><i class="fas fa-arrow-down"></i></div>
            <h3><?php echo $totalDeposits;?> <?php echo $currency;?></h3>
            <p>Deposits</p>
        </div>
    </section>
    
       
       
       <div class="gs-overlay" id="getStartedOverlay">
    <div class="get-started-popup">
        <span onclick="closePopup()" class="cse-btn">X</span>
        <h2>Get Started</h2>
       <form id="authForm">
    <input id="upline" value="<?php echo $upline; ?>" type="hidden">
    <label for="walletAddress">Wallet Address</label>
    <input type="text" id="walletAddress" class="custom-input" placeholder="Enter your wallet address" required>
    <label for="password">Password</label>
    <input type="password" id="password" class="custom-input" placeholder="Enter your password" required>
    <p class="result" id="result"></p>
    <button type="button" onclick="startMining()" class="gs-btn">Get Started</button>
</form>

        <a onclick="forrget()" class="forgot-password-link">Forgotten Password?</a>
    </div>
</div>
<div class="gs-overlay" id="forgottenOverlay">
    <div class="get-started-popup">
        <span onclick="closePopup()" class="cse-btn">X</span>
          <h3>Enter Your Wallet Address</h2>
            <p> An Email will be sent with a reset link</p>
        <form id="forgottenForm">
             <input id="upline" value="<?php echo $upline; ?>" type="hidden">
        <label for="walletAddress">Wallet Address</label>
        <input type="text" id="Address" class="custom-input" placeholder="Enter your wallet address" required>
        <p class="result" id="fresult"></p>
        <button type="button" onclick="sendForgotten()" class="gs-btn">  Continue</button>
        
        </form>
    </div>
</div>
        
   
    </div>
<?php
include_once "includes/footer.php";
?>

  
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script src="script.js">
    </script>
</body>
</html>













