<?php
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }

    return rmdir($dir);
}

$installFolder = '../install';

        // .htaccess moved successfully

        // Redirect to /admin
if (deleteDirectory($installFolder)) {
   header("Location: ../admin");
        exit();
   
} else {
    // Error deleting /install folder
    echo "Error: Unable to delete the /install folder.";
}
 
?>
