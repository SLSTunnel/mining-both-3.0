
<?php
$dbHost = "Your_Actual_Database_Host";
$dbPort = "Your_Actual_Database_Port"; // Use the correct port if it's different from the default (3306)
$dbName = "Your_Actual_Database_Name";
$dbUsername = "Your_Actual_Database_Username";
$dbPassword = "Your_Actual_Database_Password";

$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPort);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>