<?php
include_once "../includes/settings.php";
include_once "../includes/head.php";
include_once "../config/dbconfig.php";
$withsql = "SELECT * FROM withdrawals WHERE status = 'success' ORDER BY created_at DESC";
$withresult = $conn->query($withsql);
$depsql = "SELECT * FROM user_deposits WHERE status = 'success' ORDER BY created_at DESC";

$depresult = $conn->query($depsql);
?>

<body>

<div class="payouts-container">
    <div class="payouts-header">LATEST PAYOUTS</div>
    <div class="payouts-description">
        We are experts in the field of trading and investment of <?php echo $currency; ?>, and we're want to share our best practice with EVERYONE! <?php echo $currency; ?> market capitalization growing every day. Don't miss your chance to earn on this wave. Join our Platform now!
    </div>
<div class="tabs">
<h2 class="center underline">Last Withdrawals</h2>
    <table class="payouts-table" id="withdrawalsTable">
        <thead>
            <tr>
                <th>Wallet</th>
                <th>Amount</th>
                <th>txHash</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
                       
            <?php
       if ($withresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $withresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['username'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        echo '<td>' . $row['txHash'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="5">No withdrawals Yet</td></tr>';
}
        ?>
            <!-- Add withdrawal data here -->
        </tbody>
    </table>
    </div>
    <div class="tabs">
<h2 class="center underline">Last Deposits</h2>
    <table class="payouts-table" id="depositsTable">
        <thead>
            <tr>
                <th> ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
                                    
            <?php
       if ($depresult->num_rows > 0) {
    // Loop through the result set and display each row in the table
    while ($row = $depresult->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['user_id'] . '</td>';
        echo '<td>' . $row['amount'] . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '<td>' . $row['created_at'] . '</td>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    // If there are no withdrawals, display a message
    echo '<tr><td colspan="4">No Deposits Yet</td></tr>';
}
        ?>
            <!-- Add deposit data here -->
        </tbody>
    </table>
    </div>
</div>

</body>

<?php
include_once "../includes/footer.php";
?>