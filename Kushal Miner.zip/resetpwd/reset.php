<?php
include '../config/dbconfig.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if username and passwords are set
    if (isset($_POST['username'], $_POST['new_password'], $_POST['confirm_password'])) {
        $username = $_POST['username'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];

        // Check if new password matches the confirmation
        if ($newPassword === $confirmPassword) {
            // Hash the new password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update the user's password in the database
            $updatePasswordQuery = "UPDATE users SET password = ? WHERE username = ?";
            $stmt = $conn->prepare($updatePasswordQuery);
            $stmt->bind_param("ss", $hashedPassword, $username);
            $stmt->execute();
            $stmt->close();

            // Redirect to success.php
            header('Location: success.php');
            exit();
        } else {
            // Passwords do not match, handle accordingly (display an error message, redirect, etc.)
            echo '<h1>Passwords do not match</h1>';
        }
    } else {
        // Missing required parameters, handle accordingly
        echo 'Missing required parameters';
    }
}
?>
