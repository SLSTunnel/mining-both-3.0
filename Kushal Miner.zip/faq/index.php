<?php
include_once "../includes/settings.php";
include_once "../includes/head.php";
?>
<body>

<div class="faq-container">
    <!-- FAQ Item 1 -->
    <div class="faq-item">
        <div class="faq-question" onclick="toggleAnswer('faq1')">
            <i class="fas fa-plus toggle-icon"></i> What is TRX mining?
        </div>
        <div class="faq-answer" id="faq1">
            TRX mining is the process of earning TRX (Tron) cryptocurrency by participating in the verification of transactions on the Tron blockchain.
        </div>
    </div>

    <!-- FAQ Item 2 -->
    <div class="faq-item">
        <div class="faq-question" onclick="toggleAnswer('faq2')">
            <i class="fas fa-plus toggle-icon"></i> How can I start TRX mining?
        </div>
        <div class="faq-answer" id="faq2">
            To start TRX mining, you need to create an account on our platform, choose a mining plan, and make a deposit. Once your deposit is confirmed, you will start earning TRX based on the selected plan.
        </div>
    </div>

    <!-- Add 10 more FAQ items as needed -->

    <!-- FAQ Item 3 -->
    <div class="faq-item">
        <div class="faq-question" onclick="toggleAnswer('faq3')">
            <i class="fas fa-plus toggle-icon"></i> Is TRX mining profitable?
        </div>
        <div class="faq-answer" id="faq3">
            Yes, TRX mining can be profitable. The profitability depends on various factors such as the current TRX value, mining difficulty, and your chosen mining plan.
        </div>
    </div>

    <!-- FAQ Item 4 -->
    <div class="faq-item">
        <div class="faq-question" onclick="toggleAnswer('faq4')">
            <i class="fas fa-plus toggle-icon"></i> Can I mine TRX with any computer?
        </div>
        <div class="faq-answer" id="faq4">
            TRX mining typically requires specialized hardware. It's recommended to use ASIC miners for efficient and profitable TRX mining.
        </div>
    </div>

    <!-- FAQ Item 5 -->
    <!-- Add more FAQ items as needed -->

</div>

<?php
include_once "../includes/footer.php";
?>
</body>
</html>
