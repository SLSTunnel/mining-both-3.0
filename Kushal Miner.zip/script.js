  function getStartedPopup() {
            document.getElementById("getStartedOverlay").style.display = "flex";
        }

        function closePopup() {
            document.getElementById("getStartedOverlay").style.display = "none";
            document.getElementById("forgottenOverlay").style.display = "none";
        }
        
        function forrget() {
            document.getElementById("getStartedOverlay").style.display = "none";
            document.getElementById("forgottenOverlay").style.display = "flex";
        
        }
        function startMining() {
    const walletAddress = document.getElementById("walletAddress").value;
    const password = document.getElementById("password").value;
    const upline = document.getElementById("upline").value;
    const resultElement = document.getElementById("result");
    
 resultElement.innerHTML = "Loading...";
 event.preventDefault();
    // Using jQuery for AJAX
    $.ajax({
        type: "POST",
        url: "auth.php",
        data: { username: walletAddress, password: password, upline: upline },
        dataType: "json",
        success: function (response) {
            if (response.status === "success") {
                resultElement.innerHTML = "Login Success";
                // Redirect to ../dashboard (replace with your actual URL)
                window.location.href = "../dashboard";
            } else {
                resultElement.innerHTML = response.error;
            }
        },
        error: function () {
            resultElement.innerHTML = "An error occurred during the request.";
        }
    });
}




function sendForgotten() {
    
    const walletAddress = document.getElementById("Address").value;
    const resultElement = document.getElementById("fresult");
 resultElement.innerHTML = "Loading...";
     event.preventDefault();
     $.ajax({
        type: "POST",
        url: "reset.php",
        data: { username: walletAddress },
        dataType: "json",
        success: function (response) {
            if (response.status === "success") {
                // Redirect to ../dashboard (replace with your actual URL)
               resultElement.innerHTML = 'An Email As Been Sent to you with a reset link';
            } else {
                resultElement.innerHTML = response.error;
            }
        },
        error: function () {
            resultElement.innerHTML = "An error occurred during the request.";
        }
    });
}